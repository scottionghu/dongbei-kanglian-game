# -*- coding: utf-8 -*-
"""东北抗联·林海雪原 —— 二战题材第一人称射击小游戏 (光线投射伪3D)

背景: 1936年冬, 东北抗日联军战士在林海雪原中抗击日寇。

操作:
    WASD        移动            鼠标       视角
    左键        开火            右键(按住) 机瞄(开镜)
    R           换弹            Z          趴下/起身
    C           蹲下/起身       Q / E      左右探头
    1/2/3/滚轮  切换枪械        I          检视枪械
    G           投掷手榴弹      F          交互 / 操作固定机枪
    F2(按住)    指令/台词轮盘   5(按住)    药品轮盘
    ESC         退出

补给规则: 击杀敌人 备弹+12, 手榴弹+0.2 (攒满1个才显示/可用)
"""
import array
import asyncio
import math
import random

import pygame

# ---------------- 基本配置 ----------------
W, H = 960, 600
FPS = 60
NUM_RAYS = 240
COL_W = W // NUM_RAYS
FOV = math.radians(75)
FOV_ADS = math.radians(48)
HORIZON = H // 2

EYE_STAND, EYE_CROUCH, EYE_PRONE = 0.55, 0.36, 0.16

# 地图: 0空地 1树 2木屋 3沙袋 4石头
MAP_STR = [
    "11111111111111111111",
    "10000100000000010001",
    "10000000011000000001",
    "10002200000000220001",
    "10002200004000220001",
    "10000000000000000001",
    "10001000000000001001",
    "10000000400000000001",
    "10000000000000000001",
    "10030000000000000301",
    "10000001100000000001",
    "10000000000000000001",
    "10004000000000400001",
    "10000000000000000001",
    "10000333000333000001",
    "10000000000000000001",
    "10000000000000000001",
    "10000000000000000001",
    "10001000000000010001",
    "11111111111111111111",
]
MAP = [[int(c) for c in row] for row in MAP_STR]
MW, MH = len(MAP[0]), len(MAP[0])

WALL_COLORS = {
    1: ((45, 70, 40), (35, 55, 32)),     # 树
    2: ((110, 80, 50), (88, 64, 40)),    # 木屋
    3: ((150, 130, 95), (120, 104, 76)), # 沙袋
    4: ((120, 120, 125), (95, 95, 100)), # 石头
}

# 地图库: stages 为区域阶段, 每阶段可含多个据点(需全部攻占才进入下一阶段)
CAPTURE_R = 2.3      # 占领判定半径
MAX_ENEMIES = 16
MAPS = {
    "A": {
        "name": "林海突破",
        "desc": "3个区域: A → B1/B2 → C1/C2",
        "labels": ["A", "B1", "B2", "C1", "C2"],
        "stages": [
            [(10.0, 12.0)],
            [(6.0, 8.0), (14.0, 8.0)],
            [(6.5, 2.2), (13.5, 2.2)],
        ],
        "trenches": [
            (7.8, 15.2, 5.4, 1.4),  # 出发战壕
            (7.0, 13.2, 6.4, 1.6),  # A区南侧
            (3.6, 9.2, 3.8, 1.4),   # B1南侧
            (12.6, 9.2, 3.8, 1.4),  # B2南侧
            (4.8, 3.4, 3.6, 1.4),   # C1南侧
            (11.6, 3.4, 3.6, 1.4),  # C2南侧
        ],
    },
    "B": {
        "name": "雪原会战",
        "desc": "5个区域: A → B1/B2 → C → D1/D2 → E1/E2",
        "labels": ["A", "B1", "B2", "C", "D1", "D2", "E1", "E2"],
        "stages": [
            [(10.0, 15.0)],
            [(5.0, 11.0), (15.0, 11.0)],
            [(10.0, 9.0)],
            [(6.0, 5.5), (14.0, 5.5)],
            [(6.5, 2.2), (13.5, 2.2)],
        ],
        "trenches": [
            (7.8, 16.3, 5.4, 1.2),  # 出发战壕
            (5.0, 12.0, 3.4, 1.4),  # B1南侧
            (11.0, 12.0, 2.8, 1.4), # B2南侧
            (8.5, 10.0, 4.5, 1.3),  # C南侧
            (4.5, 6.5, 3.4, 1.4),   # D1南侧
            (12.0, 6.5, 3.4, 1.4),  # D2南侧
            (5.0, 3.4, 3.4, 1.4),   # E1南侧
            (11.0, 3.4, 2.8, 1.4),  # E2南侧
        ],
    },
    "C": {
        "name": "无尽模式",
        "desc": "3个单据点区域, 占领后对抗无尽敌军",
        "labels": ["A", "B", "C"],
        "stages": [
            [(10.0, 14.0)],
            [(5.5, 9.0)],
            [(12.0, 4.5)],
        ],
        "trenches": [
            (7.8, 15.6, 5.4, 1.3),  # 出发战壕
            (8.2, 12.4, 4.5, 1.4),  # A区南侧
            (4.0, 10.0, 3.4, 1.4),  # B区南侧
            (10.5, 5.5, 3.6, 1.4),  # C区南侧
        ],
    },
}
ALLY_SLOTS = [(-1.3, 1.0), (1.3, 1.0), (0, 1.7), (-2.0, 1.5), (2.0, 1.5)]


def is_solid(x, y):
    if x < 0 or y < 0 or x >= MW or y >= MH:
        return True
    return MAP[int(y)][int(x)] != 0


def los_clear(x1, y1, x2, y2):
    """直线视线检查"""
    dist = math.hypot(x2 - x1, y2 - y1)
    steps = max(1, int(dist / 0.1))
    for i in range(1, steps):
        t = i / steps
        if is_solid(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t):
            return False
    return True


def norm_ang(a):
    return (a + math.pi) % (2 * math.pi) - math.pi


# ---------------- 音效 (程序合成) ----------------
def _tone(freq, dur, vol):
    rate = 22050
    n = int(rate * dur)
    buf = array.array("h")
    for i in range(n):
        wave = 1 if int(i / rate * freq * 2) % 2 == 0 else -1
        buf.append(int(wave * (1 - i / n) * vol * 32767))
    return pygame.mixer.Sound(buffer=buf.tobytes())


def _noise(dur, vol, decay=0.92):
    rate = 22050
    n = int(rate * dur)
    buf = array.array("h")
    val = 0
    for i in range(n):
        val = int(val * decay + random.uniform(-1, 1) * 6000)
        buf.append(int(val * (1 - i / n) * vol))
    return pygame.mixer.Sound(buffer=buf.tobytes())


def _reload_sound():
    rate = 22050
    n = int(rate * 0.5)
    buf = array.array("h", bytes(n * 2))
    for click_at in (int(rate * 0.05), int(rate * 0.3)):
        for i in range(int(rate * 0.04)):
            if click_at + i < n:
                buf[click_at + i] = int(random.uniform(-1, 1) * 12000 * (1 - i / (rate * 0.04)))
    return pygame.mixer.Sound(buffer=buf.tobytes())


def load_sounds():
    try:
        if pygame.mixer.get_init() is None:
            pygame.mixer.init()
        return {
            "rifle": _noise(0.12, 1.0, 0.85),
            "pistol": _noise(0.09, 0.8, 0.85),
            "lmg": _noise(0.08, 0.7, 0.85),
            "enemy": _noise(0.1, 0.35, 0.85),
            "bolt": _tone(1400, 0.05, 0.2),
            "reload": _reload_sound(),
            "boom": _noise(0.7, 0.9, 0.95),
            "hit": _tone(2000, 0.04, 0.25),
            "hurt": _noise(0.15, 0.5, 0.9),
            "empty": _tone(900, 0.04, 0.2),
        }
    except Exception:
        return {}


def play(sounds, name):
    s = sounds.get(name)
    if s:
        s.play()


# ---------------- 字体 ----------------
CN_FONT_PATHS = (
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/msyh.ttf",
    "C:/Windows/Fonts/simhei.ttf",
    "C:/Windows/Fonts/simsun.ttc",
)


def make_font(size, bold=False):
    for p in CN_FONT_PATHS:
        try:
            f = pygame.font.Font(p, size)
            f.set_bold(bold)
            return f
        except Exception:
            continue
    f = pygame.font.Font(None, size)
    f.set_bold(bold)
    return f


# ---------------- 枪械定义 ----------------
# (名称, 弹匣, 伤害, 射速间隔, 全自动, 腰射散布°, 开镜散布°, 换弹时间, 音效, 简介)
WEAPONS = [
    {"name": "三八式步枪", "mag": 5, "dmg": 100, "interval": 1.1, "auto": False,
     "spread_hip": 2.6, "spread_ads": 0.15, "reload": 2.6, "snd": "rifle",
     "info": "缴获自日军的制式步枪, 射程远, 威力大, 抗联战士称它'三八大盖'。"},
    {"name": "毛瑟C96手枪", "mag": 10, "dmg": 34, "interval": 0.22, "auto": False,
     "spread_hip": 3.4, "spread_ads": 0.9, "reload": 2.0, "snd": "pistol",
     "info": "俗称'盒子炮'/'驳壳枪', 中国战场上的传奇手枪, 抗联干部的最爱。"},
    {"name": "ZB-26轻机枪", "mag": 20, "dmg": 25, "interval": 0.12, "auto": True,
     "spread_hip": 4.5, "spread_ads": 1.4, "reload": 3.2, "snd": "lmg",
     "info": "捷克造轻机枪, 抗联火力核心, 战士们亲切称它'捷克式'。"},
]
MG_NEST = {"name": "九二式重机枪", "mag": 200, "dmg": 22, "interval": 0.085,
           "auto": True, "spread_hip": 1.6, "spread_ads": 0.9, "reload": 4.0,
           "snd": "lmg", "info": "缴获的九二式重机枪, 阵地防御的利器。"}
AA_NEST = {"name": "九六式25mm防空炮", "mag": 60, "dmg": 55, "interval": 0.45,
           "auto": True, "spread_hip": 0.8, "spread_ads": 0.4, "reload": 3.5,
           "snd": "lmg", "info": "双联装防空炮, 可射击空中敌机。"}
ROCKET_LAUNCHER = {"name": "火箭筒", "mag": 1, "dmg": 50, "interval": 1.5,
                   "auto": False, "spread_hip": 2.0, "spread_ads": 1.0,
                   "reload": 3.0, "snd": "lmg", "info": "反坦克火箭筒, 高爆/穿甲双模式。"}


# ---------------- 武器模型绘制 (侧视图Surface) ----------------
def build_weapon_surface(idx):
    """程序化绘制枪械侧视图, 返回Surface"""
    if idx == 0:  # 三八式步枪
        s = pygame.Surface((420, 120), pygame.SRCALPHA)
        wood = (120, 78, 42)
        steel = (55, 55, 60)
        pygame.draw.polygon(s, wood, [(20, 70), (200, 62), (200, 78), (90, 95), (20, 100)])
        pygame.draw.rect(s, wood, (195, 58, 160, 22))          # 护木
        pygame.draw.rect(s, steel, (350, 62, 66, 7))           # 枪管
        pygame.draw.rect(s, steel, (200, 56, 150, 6))          # 枪管上沿
        pygame.draw.rect(s, steel, (185, 66, 20, 26))          # 枪机
        pygame.draw.circle(s, steel, (210, 92), 6)             # 拉机柄
        pygame.draw.rect(s, (90, 60, 32), (16, 78, 60, 30))    # 枪托
        pygame.draw.rect(s, steel, (340, 52, 4, 12))           # 准星
        return s
    if idx == 1:  # 毛瑟C96
        s = pygame.Surface((260, 140), pygame.SRCALPHA)
        wood = (130, 60, 40)
        steel = (60, 60, 66)
        pygame.draw.rect(s, steel, (60, 40, 150, 26))          # 枪身
        pygame.draw.rect(s, steel, (205, 46, 50, 10))          # 枪管
        pygame.draw.rect(s, steel, (95, 66, 22, 40))           # 弹匣(身前)
        pygame.draw.polygon(s, wood, [(60, 66), (40, 120), (62, 124), (82, 70)])  # 握把
        pygame.draw.circle(s, steel, (90, 82), 7)              # 击锤
        pygame.draw.rect(s, steel, (200, 34, 4, 10))           # 准星
        return s
    if idx == 2:  # ZB-26
        s = pygame.Surface((420, 150), pygame.SRCALPHA)
        wood = (110, 70, 40)
        steel = (58, 58, 64)
        pygame.draw.rect(s, steel, (120, 70, 220, 26))         # 机匣+枪管
        pygame.draw.rect(s, steel, (330, 76, 70, 10))          # 枪口段
        for i in range(6):                                     # 散热环
            pygame.draw.rect(s, (45, 45, 50), (250 + i * 12, 66, 5, 34))
        pygame.draw.rect(s, steel, (160, 20, 34, 52))          # 顶部弹匣
        pygame.draw.polygon(s, wood, [(20, 82), (118, 74), (118, 98), (30, 118)])  # 枪托
        pygame.draw.rect(s, steel, (300, 96, 8, 30))           # 两脚架
        pygame.draw.rect(s, steel, (316, 96, 8, 30))
        return s
    # 九二式重机枪(固定)
    s = pygame.Surface((460, 200), pygame.SRCALPHA)
    steel = (60, 62, 66)
    pygame.draw.rect(s, steel, (80, 70, 220, 40))              # 枪身
    pygame.draw.rect(s, steel, (290, 80, 140, 14))             # 枪管
    for i in range(8):                                         # 散热片
        pygame.draw.rect(s, (45, 47, 50), (300 + i * 15, 70, 6, 34))
    pygame.draw.rect(s, (90, 90, 96), (40, 78, 44, 24))        # 保弹板
    pygame.draw.line(s, (70, 50, 30), (180, 110), (120, 190), 8)   # 三脚架
    pygame.draw.line(s, (70, 50, 30), (200, 110), (260, 190), 8)
    pygame.draw.line(s, (70, 50, 30), (190, 110), (190, 190), 8)
    return s


def build_enemy_surface():
    """日军士兵立绘 (面向玩家, 双手端枪指向玩家)"""
    s = pygame.Surface((100, 150), pygame.SRCALPHA)
    skin = (225, 190, 150)
    uniform = (96, 100, 60)     # 黄绿色军装
    helmet = (80, 85, 50)
    pygame.draw.rect(s, uniform, (28, 55, 44, 70))             # 身体
    pygame.draw.rect(s, uniform, (20, 60, 14, 45))             # 手臂
    pygame.draw.rect(s, uniform, (66, 60, 14, 45))
    pygame.draw.rect(s, (70, 70, 45), (32, 125, 14, 22))       # 腿
    pygame.draw.rect(s, (70, 70, 45), (54, 125, 14, 22))
    pygame.draw.circle(s, skin, (50, 42), 14)                  # 脸
    pygame.draw.polygon(s, helmet, [(32, 40), (50, 20), (68, 40)])  # 钢盔
    pygame.draw.rect(s, helmet, (30, 38, 40, 6))
    # 端枪指向玩家: 木托枪身 + 枪管缩短 + 枪口正对玩家(黑洞)
    pygame.draw.line(s, (95, 66, 38), (72, 98), (52, 76), 8)   # 枪身(木托)
    pygame.draw.line(s, (48, 48, 54), (54, 74), (50, 71), 7)   # 枪管(透视缩短)
    pygame.draw.circle(s, (22, 22, 26), (50, 70), 5)           # 枪口正对玩家
    pygame.draw.circle(s, skin, (72, 96), 5)                   # 双手握枪
    pygame.draw.circle(s, skin, (56, 82), 5)
    return s


def build_ally_surface():
    """抗联战友立绘 (灰褐棉服 + 狗皮帽 + 红臂章, 端枪)"""
    s = pygame.Surface((100, 150), pygame.SRCALPHA)
    skin = (230, 195, 160)
    uniform = (92, 86, 74)
    hat = (110, 82, 54)
    pygame.draw.rect(s, uniform, (28, 55, 44, 70))             # 身体
    pygame.draw.rect(s, uniform, (20, 60, 14, 45))             # 手臂
    pygame.draw.rect(s, uniform, (66, 60, 14, 45))
    pygame.draw.rect(s, (60, 56, 48), (32, 125, 14, 22))       # 腿
    pygame.draw.rect(s, (60, 56, 48), (54, 125, 14, 22))
    pygame.draw.rect(s, (180, 60, 50), (18, 70, 18, 9))        # 红臂章
    pygame.draw.circle(s, skin, (50, 42), 14)                  # 脸
    pygame.draw.polygon(s, hat, [(31, 40), (50, 21), (69, 40)])  # 狗皮帽
    pygame.draw.rect(s, hat, (27, 38, 46, 7))
    pygame.draw.line(s, (95, 66, 38), (72, 98), (52, 76), 8)   # 枪身(木托)
    pygame.draw.line(s, (48, 48, 54), (54, 74), (50, 71), 7)   # 枪管
    pygame.draw.circle(s, (22, 22, 26), (50, 70), 5)           # 枪口
    pygame.draw.circle(s, skin, (72, 96), 5)                   # 双手
    pygame.draw.circle(s, skin, (56, 82), 5)
    return s


def build_rocket_surface():
    """火箭筒 (RPG风格, 侧视)"""
    s = pygame.Surface((120, 60), pygame.SRCALPHA)
    green = (78, 92, 60)
    dark = (55, 65, 45)
    pygame.draw.rect(s, green, (20, 22, 80, 14))               # 发射筒
    pygame.draw.rect(s, dark, (15, 18, 12, 22))                # 尾喷
    pygame.draw.rect(s, dark, (95, 20, 18, 18))                # 弹头
    pygame.draw.rect(s, (100, 110, 80), (40, 12, 20, 8))       # 瞄具
    return s


def build_tank_surface():
    """日军坦克 (九七式中战车, 侧视)"""
    s = pygame.Surface((200, 120), pygame.SRCALPHA)
    green = (78, 88, 58)
    dark = (55, 62, 42)
    pygame.draw.ellipse(s, dark, (20, 70, 160, 40))            # 车体
    pygame.draw.rect(s, green, (60, 40, 80, 34))               # 炮塔
    pygame.draw.rect(s, dark, (130, 52, 55, 10))               # 炮管
    pygame.draw.circle(s, (40, 45, 32), (55, 88), 14)          # 诱导轮
    pygame.draw.circle(s, (40, 45, 32), (145, 88), 14)         # 主动轮
    pygame.draw.circle(s, (40, 45, 32), (100, 92), 12)         # 负重轮
    pygame.draw.rect(s, (30, 33, 25), (95, 30, 10, 12))        # 舱盖
    return s


def build_aa_surface():
    """九六式25mm防空炮 (双联装高射炮, 侧视)"""
    s = pygame.Surface((160, 120), pygame.SRCALPHA)
    green = (86, 100, 66)
    dark = (60, 70, 48)
    pygame.draw.ellipse(s, dark, (20, 78, 120, 36))            # 底座
    pygame.draw.rect(s, green, (58, 46, 34, 36))               # 炮座
    pygame.draw.line(s, (50, 55, 40), (75, 52), (128, 10), 9)  # 炮管1(抬升)
    pygame.draw.line(s, (50, 55, 40), (72, 58), (122, 18), 9)  # 炮管2
    pygame.draw.circle(s, (70, 80, 55), (75, 50), 14)          # 炮盾
    pygame.draw.circle(s, (30, 33, 26), (39, 104), 9)          # 轮子
    pygame.draw.circle(s, (30, 33, 26), (110, 102), 9)
    return s


# ---------------- 游戏对象 ----------------
class Enemy:
    def __init__(self, x, y, wave):
        self.x, self.y = x, y
        self.hp = 100
        self.speed = random.uniform(0.9, 1.3) + wave * 0.04
        self.fire_t = random.uniform(1.5, 3.0)
        self.strafe_dir = random.choice([-1, 1])
        self.strafe_t = random.uniform(1, 3)
        self.flash_t = 0.0
        self.stuck_t = 0.0
        self.avoid_t = 0.0
        self.avoid_dir = 1
        self.alive = True

    def update(self, dt, game):
        # 选择最近目标: 玩家或队友
        best = game.player
        bd = math.hypot(best.x - self.x, best.y - self.y)
        for a in game.allies:
            if a.alive:
                d = math.hypot(a.x - self.x, a.y - self.y)
                if d < bd:
                    best, bd = a, d
        is_player = best is game.player
        self.flash_t = max(0.0, self.flash_t - dt)
        dx, dy = best.x - self.x, best.y - self.y
        dist = max(0.1, bd)
        # 移动: 12格外驻守据点, 4.5~12接近, 4.5内游走
        if self.avoid_t > 0:
            # 被障碍卡住时: 沿垂直方向绕行
            self.avoid_t -= dt
            step = self.speed * dt
            px_, py_ = -dy / dist * self.avoid_dir, dx / dist * self.avoid_dir
            if not is_solid(self.x + px_ * step, self.y):
                self.x += px_ * step
            if not is_solid(self.x, self.y + py_ * step):
                self.y += py_ * step
        elif 4.5 < dist <= 12:
            step = self.speed * dt
            nx = self.x + dx / dist * step
            ny = self.y + dy / dist * step
            ox, oy = self.x, self.y
            if not is_solid(nx, self.y):
                self.x = nx
            if not is_solid(self.x, ny):
                self.y = ny
            # 实际位移远小于预期 -> 判定卡住, 触发绕行
            if math.hypot(self.x - ox, self.y - oy) < step * 0.3:
                self.stuck_t += dt
                if self.stuck_t > 0.4:
                    self.stuck_t = 0.0
                    self.avoid_t = 0.7
                    self.avoid_dir = random.choice([-1, 1])
            else:
                self.stuck_t = 0.0
        else:
            # 近距离游走 / 远距离驻守
            self.strafe_t -= dt
            if self.strafe_t <= 0:
                self.strafe_dir *= -1
                self.strafe_t = random.uniform(1, 2.5)
            step = self.speed * (0.6 if dist <= 4.5 else 0.25) * dt
            px_, py_ = -dy / dist * self.strafe_dir, dx / dist * self.strafe_dir
            if not is_solid(self.x + px_ * step, self.y + py_ * step):
                self.x += px_ * step
                self.y += py_ * step
        # 射击最近目标
        self.fire_t -= dt
        if self.fire_t <= 0 and dist < 13 and los_clear(self.x, self.y, best.x, best.y):
            self.fire_t = random.uniform(1.4, 2.8)
            self.flash_t = 0.09
            play(game.sounds, "enemy")
            acc = 0.42 - dist * 0.02
            if is_player:
                if best.stance == 2:
                    acc -= 0.13
                elif best.stance == 1:
                    acc -= 0.06
                if best.moving:
                    acc -= 0.06
            else:
                acc -= 0.08
            if random.random() < max(0.05, acc):
                if is_player:
                    game.hurt_player(random.randint(8, 16))
                else:
                    best.hp -= random.randint(8, 14)
                    if best.hp <= 0:
                        best.alive = False
                        game.floats.append(["战友倒下了!", best.x, best.y, 1.5])


class Ally:
    """抗联战友: 向据点推进, 自动交战"""

    def __init__(self, x, y, slot):
        self.x, self.y = x, y
        self.hp = 80
        self.slot = slot % len(ALLY_SLOTS)
        self.fire_t = random.uniform(1.0, 2.0)
        self.flash_t = 0.0
        self.stuck_t = 0.0
        self.avoid_t = 0.0
        self.avoid_dir = 1
        self.alive = True

    def update(self, dt, game):
        self.flash_t = max(0.0, self.flash_t - dt)
        # 索敌: 视线内11格最近敌人
        target, td = None, 11.0
        for en in game.enemies:
            if not en.alive:
                continue
            d = math.hypot(en.x - self.x, en.y - self.y)
            if d < td and los_clear(self.x, self.y, en.x, en.y):
                target, td = en, d
        if target is not None:
            self.fire_t -= dt
            if self.fire_t <= 0:
                self.fire_t = random.uniform(1.6, 2.6)
                self.flash_t = 0.08
                if random.random() < 0.55:
                    target.hp -= 22
                    if target.hp <= 0:
                        game.kill_enemy(target)
            return
        # 无敌情: 向最近的未攻占区域点推进 (玩家离点远时先跟随玩家)
        pts = game.active_points()
        if not pts:
            return
        px_, py_ = min(((x, y) for x, y, _ in pts),
                       key=lambda t: math.hypot(t[0] - self.x, t[1] - self.y))
        off = ALLY_SLOTS[self.slot]
        if math.hypot(game.player.x - px_, game.player.y - py_) > 6.5:
            gx, gy = game.player.x + off[0] * 1.6, game.player.y + off[1] * 1.6
        else:
            gx, gy = px_ + off[0], py_ + off[1]
        dx, dy = gx - self.x, gy - self.y
        dist = math.hypot(dx, dy)
        if dist < 0.6:
            return
        step = 2.2 * dt
        if self.avoid_t > 0:
            self.avoid_t -= dt
            px_, py_ = -dy / dist * self.avoid_dir, dx / dist * self.avoid_dir
            if not is_solid(self.x + px_ * step, self.y):
                self.x += px_ * step
            if not is_solid(self.x, self.y + py_ * step):
                self.y += py_ * step
            return
        nx = self.x + dx / dist * step
        ny = self.y + dy / dist * step
        ox, oy = self.x, self.y
        if not is_solid(nx, self.y):
            self.x = nx
        if not is_solid(self.x, ny):
            self.y = ny
        if math.hypot(self.x - ox, self.y - oy) < step * 0.3:
            self.stuck_t += dt
            if self.stuck_t > 0.4:
                self.stuck_t = 0.0
                self.avoid_t = 0.7
                self.avoid_dir = random.choice([-1, 1])
        else:
            self.stuck_t = 0.0


class Grenade:
    def __init__(self, x, y, angle, ntype="grenade"):
        self.x, self.y = x, y
        self.z = 0.55
        self.ntype = ntype  # grenade / molotov
        spd = 9.0
        self.vx = math.cos(angle) * spd
        self.vy = math.sin(angle) * spd
        self.vz = 3.2
        self.fuse = 2.2 if ntype == "grenade" else 1.5

    def update(self, dt):
        self.fuse -= dt
        self.vz -= 9.8 * dt
        nx = self.x + self.vx * dt
        ny = self.y + self.vy * dt
        if is_solid(nx, self.y):
            self.vx *= -0.4
        else:
            self.x = nx
        if is_solid(self.x, ny):
            self.vy *= -0.4
        else:
            self.y = ny
        self.z += self.vz * dt
        if self.z <= 0:
            self.z = 0
            self.vz *= -0.35
            self.vx *= 0.7
            self.vy *= 0.7
        return self.fuse <= 0  # True = 该爆炸了


class Player:
    def __init__(self):
        self.x, self.y = 10.5, 17.5
        self.angle = -math.pi / 2   # 面朝北
        self.pitch = 0.0
        self.hp = 100
        self.stance = 0             # 0站 1蹲 2趴
        self.eye = EYE_STAND
        self.lean = 0               # -1左 0 1右
        self.moving = False
        self.slot = 0
        self.mags = [w["mag"] for w in WEAPONS]  # 每把枪当前弹匣
        self.reserve = 90                        # 共享备弹
        self.nades = 0
        self.nade_progress = 0.0
        self.molotov = 0
        self.molotov_progress = 0.0
        self.rocket = 1
        self.rocket_progress = 0.0
        self.rocket_mode = "HE"   # HE高爆 / AP穿甲
        self.meds = {"绷带": 3, "急救包": 1, "炒面": 2}
        self.mounted = None      # None=步行, 1=九二式重机枪, 2=防空炮
        self.mg_mag = MG_NEST["mag"]
        self.aa_mag = AA_NEST["mag"]
        self.rocket_mag = 1
        self.in_tank = False     # 是否在坦克内
        self.tank_hp = 0
        self.jump_z = 0.0        # 跳跃高度
        self.jump_vz = 0.0       # 跳跃速度

    @property
    def weapon(self):
        if self.mounted == 1:
            return MG_NEST
        if self.mounted == 2:
            return AA_NEST
        if self.slot == 3:
            return ROCKET_LAUNCHER
        return WEAPONS[self.slot]

    @property
    def cur_mag(self):
        if self.mounted == 1:
            return self.mg_mag
        if self.mounted == 2:
            return self.aa_mag
        if self.slot == 3:
            return self.rocket_mag
        return self.mags[self.slot]

    def use_mag(self):
        if self.mounted == 1:
            self.mg_mag -= 1
        elif self.mounted == 2:
            self.aa_mag -= 1
        elif self.slot == 3:
            self.rocket_mag -= 1
        else:
            self.mags[self.slot] -= 1

    def speed(self):
        base = 3.2
        if self.stance == 1:
            base *= 0.55
        elif self.stance == 2:
            base *= 0.25
        if self.in_tank:
            base = 2.0
        return base


# ---------------- 主游戏 ----------------
class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("东北抗联 · 林海雪原")
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        pygame.key.stop_text_input()  # 禁用文本输入, 防止输入法(如微信输入法)拦截WASD
        # 场景状态: lobby(大厅选图) -> game(战斗)
        self.scene = "lobby"
        self.lobby_cards = []
        self.show_keys = False   # 大厅键位指南
        self.map_key = "A"
        self.stages = MAPS["A"]["stages"]
        self.trench_list = MAPS["A"]["trenches"]
        self.map_labels = MAPS["A"]["labels"]
        self.clock = pygame.time.Clock()
        self.font = make_font(20, True)
        self.small = make_font(16)
        self.big = make_font(52, True)
        self.sounds = load_sounds()
        self.enemy_img = build_enemy_surface()
        self.ally_img = build_ally_surface()
        self.weapon_imgs = [build_weapon_surface(i) for i in range(3)]
        self.mg_img = build_weapon_surface(3)
        self.rocket_img = build_rocket_surface()
        self.tank_img = build_tank_surface()
        self.aa_img = build_aa_surface()
        self._sprite_cache = {}
        self.reset()
        # 大厅阶段: 显示鼠标, 不锁定 (reset不碰鼠标状态, 避免开局呼出光标)
        pygame.mouse.set_visible(True)
        pygame.event.set_grab(False)

    def reset(self):
        self.player = Player()
        self.enemies = []
        self.grenades = []
        self.floats = []       # 飘字 [text, x, y, t]
        self.shout = None      # (text, t)
        self.wave = 0
        self.kills = 0
        self.spawn_delay = 2.0
        self.fire_cd = 0.0
        self.reloading = 0.0
        self.switching = 0.0
        self.pending_slot = -1
        self.inspecting = 0.0
        self.bloom = 0.0       # 腰射散布扩张
        self.recoil = 0.0
        self.shake = 0.0
        self.hurt_flash = 0.0
        self.hitmark = 0.0
        self.hitmark_kill = False
        self.grenade_cd = 0.0
        self.over = False
        self.ads = False
        self.fov = FOV
        self.tanks = [self.spawn_tank()]  # 初始一辆坦克
        self.tank_spawn_t = 25.0
        self.nest = (10.5, 15.2)  # 固定机枪位置
        self.aa_pos = (5.5, 11.5)  # 防空炮位置
        # 飞机 / 分数 / 炮击支援
        self.planes = []
        self.plane_t = random.uniform(8.0, 16.0)
        self.score = 0
        self.last_hurt_t = -99.0   # 呼吸回血计时
        self.regen_active = False
        self.strike_ui = None
        self.strike_shells = []   # [延时, x, y]
        self.strike_fx = []       # [x, y, 剩余时间]
        self.hint_t = 8.0
        # 天气与寒冷系统
        self.t = 0.0
        self.cold = 0.0            # 寒冷值
        self.cold_drain_acc = 0.0  # 失温扣血计时
        self.fire_wait = 0.0       # 篝火取暖计时
        self.campfires = []
        for _ in range(3):
            self.spawn_campfire()
        self.fire_move_t = 30.0    # 篝火随机刷新间隔
        self.snow = [[random.uniform(-20, W + 20), random.uniform(0, H),
                      random.uniform(50, 140), random.randint(1, 3)]
                     for _ in range(130)]
        self.death_reason = "壮烈牺牲"
        # 据点攻占与队友 (按所选地图初始化)
        idx = 0
        self.point_labels = []
        for stage in self.stages:
            self.point_labels.append(self.map_labels[idx:idx + len(stage)])
            idx += len(stage)
        self.point_prog = [[0.0] * len(s) for s in self.stages]   # 每点占领进度
        self.point_done = [[False] * len(s) for s in self.stages] # 每点是否攻占
        self.allies = []
        self.sh_idx = 0            # 当前目标阶段
        self.zone_counts = []      # 当前阶段每点 (我方, 敌方) 人数
        self.evac_t = 0.0          # 撤离倒计时
        self.reinforce_t = 15.0
        self.victory = False
        self.endless = False       # 无尽模式 (地图C: 占领后持续对抗)
        self.endless_t = 0.0
        self.endless_spawn_t = 5.0
        self.endless_ally_t = 45.0
        self.warm_extra = 0.0      # 驱寒后继续烤火回血计时
        self.wave = 1
        for i, ax in enumerate((-1.0, 0.0, 1.0)):
            self.allies.append(Ally(10.5 + ax, 16.4, i))
        self.spawn_defenders()

    def spawn_campfire(self):
        """在随机空地生成一处篝火 (远离玩家/机枪位/其他篝火)"""
        for _ in range(60):
            x = random.uniform(1.5, MW - 1.5)
            y = random.uniform(1.5, MH - 1.5)
            if is_solid(x, y):
                continue
            if math.hypot(x - self.player.x, y - self.player.y) < 4:
                continue
            if math.hypot(x - self.nest[0], y - self.nest[1]) < 3:
                continue
            if math.hypot(x - self.aa_pos[0], y - self.aa_pos[1]) < 3:
                continue
            if any(math.hypot(x - fx, y - fy) < 6 for fx, fy in self.campfires):
                continue
            self.campfires.append((x, y))
            return

    def update_weather(self, dt):
        """下雪 / 寒冷累积 / 失温扣血 / 篝火取暖与随机刷新"""
        p = self.player
        self.t += dt
        # 靠近篝火: 持续2秒 -> 寒冷归零; 之后继续烤火每2秒回2点生命
        near_fire = any(math.hypot(p.x - fx, p.y - fy) < 1.9 for fx, fy in self.campfires)
        if near_fire:
            if self.cold > 0:
                self.fire_wait += dt
                if self.fire_wait >= 2.0:
                    self.cold = 0.0
                    self.fire_wait = 0.0
                    self.warm_extra = 0.0
                    self.shout = ("寒意散去, 体温恢复!", 1.2)
            else:
                self.warm_extra += dt
                if self.warm_extra >= 2.0:
                    self.warm_extra -= 2.0
                    if p.hp < 100:
                        p.hp = min(100, p.hp + 2)
                        self.floats.append(["+2", p.x + math.cos(p.angle) * 0.6,
                                            p.y + math.sin(p.angle) * 0.6, 0.8])
        else:
            self.fire_wait = 0.0
        # 寒冷值随时间累积 (战壕内减缓一半)
        if not near_fire:
            rate = 0.6 if self.in_trench(p.x, p.y) else 1.2
            self.cold = min(120.0, self.cold + dt * rate)
        # 寒冷值超过100: 每秒扣1点生命, 直到扣完
        if self.cold > 100.0:
            self.cold_drain_acc += dt
            if self.cold_drain_acc >= 1.0:
                self.cold_drain_acc -= 1.0
                p.hp -= 1
                self.hurt_flash = max(self.hurt_flash, 0.25)
                if p.hp <= 0:
                    p.hp = 0
                    self.death_reason = "长眠于林海雪原"
                    self.over = True
        # 篝火随机迁移刷新: 挪走最旧的一处, 换个新位置
        self.fire_move_t -= dt
        if self.fire_move_t <= 0:
            self.fire_move_t = random.uniform(25, 40)
            if self.campfires:
                self.campfires.pop(0)
            self.spawn_campfire()
        # 雪花 (屏幕空间)
        for f in self.snow:
            f[1] += f[2] * dt
            f[0] += math.sin(self.t * 1.5 + f[2] * 0.1) * 14 * dt
            if f[1] > H:
                f[0], f[1] = random.uniform(-20, W + 20), -4

    def draw_snow(self):
        for x, y, _, sz in self.snow:
            pygame.draw.circle(self.screen, (240, 244, 250), (int(x), int(y)), sz)

    # ---------- 伤害/击杀 ----------
    def hurt_player(self, dmg):
        if self.over:
            return
        if self.player.mounted:
            return  # 炮位掩体保护: 重机枪/防空炮内不受伤害
        if self.in_trench(self.player.x, self.player.y):
            dmg = max(1, dmg // 2)  # 战壕掩体: 伤害减半
        self.player.hp -= dmg
        self.last_hurt_t = self.t
        self.hurt_flash = 0.5
        self.shake = max(self.shake, 4)
        play(self.sounds, "hurt")
        if self.player.hp <= 0:
            self.player.hp = 0
            self.over = True

    def kill_enemy(self, en):
        en.alive = False
        self.kills += 1
        self.score += 100
        self.player.reserve += 12
        self.player.nade_progress += 0.2
        self.player.molotov_progress += 0.15
        self.player.rocket_progress += 0.1
        self.floats.append(["+12 弹药", en.x, en.y, 1.2])
        if self.player.nade_progress >= 1.0:
            got = int(self.player.nade_progress)
            self.player.nades += got
            self.player.nade_progress -= got
            self.floats.append([f"+{got} 手榴弹", en.x, en.y, 1.6])
        if self.player.molotov_progress >= 1.0:
            got = int(self.player.molotov_progress)
            self.player.molotov += got
            self.player.molotov_progress -= got
            self.floats.append([f"+{got} 燃烧瓶", en.x, en.y, 1.6])
        if self.player.rocket_progress >= 1.0:
            got = int(self.player.rocket_progress)
            self.player.rocket += got
            self.player.rocket_progress -= got
            self.floats.append([f"+{got} 火箭弹", en.x, en.y, 1.6])

    def explode(self, x, y, ntype="grenade"):
        play(self.sounds, "boom")
        self.shake = max(self.shake, 12)
        for en in self.enemies:
            if not en.alive:
                continue
            d = math.hypot(en.x - x, en.y - y)
            if d < 3.5 and los_clear(x, y, en.x, en.y):
                en.hp -= int(140 * (1 - d / 4))
                if en.hp <= 0:
                    self.kill_enemy(en)
        # 坦克伤害
        for tk in self.tanks:
            if not tk["alive"]:
                continue
            d = math.hypot(tk["x"] - x, tk["y"] - y)
            if d < 3.0:
                if ntype == "molotov":
                    tk["hp"] -= 15
                    tk["burning"] = 3.0
                    self.shout = ("燃烧瓶命中坦克!", 1.5)
                else:
                    tk["hp"] -= 25
                    self.shout = ("手榴弹命中坦克!", 1.5)
                if tk["hp"] <= 0:
                    tk["alive"] = False
                    self.score += 500
                    self.shout = ("摧毁敌军坦克! +500", 2.0)
        pd = math.hypot(self.player.x - x, self.player.y - y)
        if pd < 2.5:
            self.hurt_player(int(60 * (1 - pd / 3)))

    # ---------- 射击 ----------
    def shoot(self):
        p = self.player
        wpn = p.weapon
        if p.cur_mag <= 0:
            play(self.sounds, "empty")
            self.fire_cd = 0.25
            return
        p.use_mag()
        self.fire_cd = wpn["interval"]
        spread = wpn["spread_ads"] if self.ads else wpn["spread_hip"]
        if not self.ads:
            spread += self.bloom * 2.0
            if p.stance == 2:
                spread *= 0.7
            elif p.stance == 1:
                spread *= 0.85
            if p.moving:
                spread *= 1.5
        self.bloom = min(3.0, self.bloom + 0.8)
        self.recoil = min(14, self.recoil + (6 if wpn["dmg"] >= 50 else 3))
        self.shake = max(self.shake, 2)
        play(self.sounds, wpn["snd"])
        # 命中判定: 找散布锥内最近的敌人
        aim = p.angle + math.radians(random.uniform(-spread, spread))
        best, best_d = None, 30.0
        for en in self.enemies:
            if not en.alive:
                continue
            d = math.hypot(en.x - p.x, en.y - p.y)
            if d >= best_d:
                continue
            diff = abs(norm_ang(math.atan2(en.y - p.y, en.x - p.x) - aim))
            if diff <= math.atan(0.32 / max(d, 0.1)) and los_clear(p.x, p.y, en.x, en.y):
                best, best_d = en, d
        if best:
            best.hp -= wpn["dmg"]
            self.hitmark = 0.15
            self.hitmark_kill = best.hp <= 0
            play(self.sounds, "hit")
            if best.hp <= 0:
                self.kill_enemy(best)
        # 火箭筒: 命中坦克
        if p.slot == 3 and not p.mounted:
            aim = p.angle + math.radians(random.uniform(-spread, spread))
            for tk in self.tanks:
                if not tk["alive"]:
                    continue
                d = math.hypot(tk["x"] - p.x, tk["y"] - p.y)
                if d > 30:
                    continue
                diff = abs(norm_ang(math.atan2(tk["y"] - p.y, tk["x"] - p.x) - aim))
                if diff <= math.atan(0.5 / max(d, 0.1)) and los_clear(p.x, p.y, tk["x"], tk["y"]):
                    dmg = 50 if p.rocket_mode == "HE" else 70
                    tk["hp"] -= dmg
                    self.shake = max(self.shake, 15)
                    play(self.sounds, "boom")
                    self.strike_fx.append([tk["x"], tk["y"], 1.3])
                    self.hitmark = 0.15
                    self.hitmark_kill = tk["hp"] <= 0
                    if tk["hp"] <= 0:
                        tk["alive"] = False
                        self.score += 500
                        self.shout = ("摧毁敌军坦克! +500", 2.0)
                    else:
                        self.shout = (f"命中坦克! -{dmg}", 1.2)
                    break
        # 防空炮: 可射击空中敌机 (准星附近判定, 准星和飞机都随pitch移动)
        if p.mounted == 2:
            cx, cy = W // 2, H // 2 + int(self.recoil * 0.3 + p.pitch)
            for pl in self.planes:
                if pl["falling"]:
                    continue
                screen_sy = pl["sy"] + (H // 2 + int(p.pitch) - HORIZON)
                if math.hypot(pl["sx"] - cx, screen_sy - cy) < 36:
                    pl["hp"] -= wpn["dmg"]
                    self.hitmark = 0.15
                    self.hitmark_kill = pl["hp"] <= 0
                    play(self.sounds, "hit")
                    if pl["hp"] <= 0:
                        pl["falling"] = True
                        pl["vy"] = 40.0
                        self.score += 200
                        self.floats.append(["+200 击落敌机!", p.x, p.y, 1.4])
                    break

    def tank_on(self, x, y):
        """返回玩家脚下所在的坦克(顶上), 否则None"""
        for tk in self.tanks:
            if tk["alive"] and math.hypot(tk["x"] - x, tk["y"] - y) < 1.0:
                return tk
        return None

    def spawn_tank(self):
        """生成一辆敌军坦克"""
        for _ in range(50):
            x = random.uniform(3, 17)
            y = random.uniform(3, 15)
            if not is_solid(x, y) and math.hypot(x - 10.5, y - 17.5) > 6:
                return {"x": x, "y": y, "hp": 100, "hatch_open": False,
                        "burning": 0.0, "alive": True, "fire_t": 0.0,
                        "interior_burn": False,
                        "angle": random.uniform(0, 2 * math.pi)}
        return {"x": 10, "y": 10, "hp": 100, "hatch_open": False,
                "burning": 0.0, "alive": True, "fire_t": 0.0,
                "interior_burn": False, "angle": 0}

    def start_reload(self):
        p = self.player
        if p.slot == 3 and not p.mounted:
            if self.reloading > 0 or p.rocket_mag >= 1:
                return
            if p.rocket >= 1:
                self.reloading = ROCKET_LAUNCHER["reload"]
                play(self.sounds, "reload")
            return
        if p.mounted:
            if self.reloading > 0:
                return
            if p.mounted == 1:
                if p.mg_mag >= MG_NEST["mag"]:
                    return
                self.reloading = MG_NEST["reload"]
            else:
                if p.aa_mag >= AA_NEST["mag"]:
                    return
                self.reloading = AA_NEST["reload"]
            play(self.sounds, "reload")
            return
        wpn = WEAPONS[p.slot]
        if self.reloading > 0 or p.mags[p.slot] >= wpn["mag"] or p.reserve <= 0:
            return
        self.reloading = wpn["reload"]
        play(self.sounds, "reload")

    # ---------- 据点攻占 ----------
    def in_trench(self, x, y):
        return any(x0 <= x <= x0 + w and y0 <= y <= y0 + h
                   for x0, y0, w, h in self.trench_list)

    def active_points(self):
        """当前阶段尚未攻占的点: [(x, y, j), ...]"""
        if self.sh_idx >= len(self.stages):
            return []
        return [(x, y, j) for j, (x, y) in enumerate(self.stages[self.sh_idx])
                if not self.point_done[self.sh_idx][j]]

    def start_map(self, key):
        """从大厅选图并开始战斗"""
        m = MAPS[key]
        self.map_key = key
        self.stages = m["stages"]
        self.trench_list = m["trenches"]
        self.map_labels = m["labels"]
        self.scene = "game"
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)
        self.reset()

    # ---------- 炮击支援 ----------
    def open_strike(self):
        """打开炮击区域选择界面"""
        self.strike_ui = {"sel": None, "rects": [], "ok_rect": None, "cancel_rect": None}
        pygame.mouse.set_visible(True)
        pygame.event.set_grab(False)

    def close_strike(self):
        self.strike_ui = None
        pygame.mouse.set_visible(False)
        pygame.event.set_grab(True)

    def call_strike(self):
        """对选中区域实施覆盖炮击"""
        si, j = self.strike_ui["sel"]
        self.score -= 20000
        cx, cy = self.stages[si][j]
        for i in range(8):
            self.strike_shells.append(
                [0.5 + i * 0.32,
                 cx + random.uniform(-1.5, 1.5),
                 cy + random.uniform(-1.5, 1.5)])
        self.close_strike()
        self.shout = ("炮火覆盖! 注意隐蔽!", 2.0)

    def draw_strike_ui(self):
        """炮击支援选择界面"""
        s = pygame.Surface((W, H), pygame.SRCALPHA)
        s.fill((10, 12, 16, 220))
        self.screen.blit(s, (0, 0))
        t = self.big.render("呼叫炮击支援", True, (255, 220, 150))
        self.screen.blit(t, t.get_rect(center=(W // 2, 60)))
        t2 = self.small.render("点击选择区域, 确认后实施覆盖射击 (消耗 20000 分)",
                               True, (200, 205, 215))
        self.screen.blit(t2, t2.get_rect(center=(W // 2, 110)))
        ui = self.strike_ui
        ui["rects"] = []
        bw, bh, gap = 150, 54, 16
        x0 = W // 2 - (4 * bw + 3 * gap) // 2
        y0 = 150
        k = 0
        for si, stage in enumerate(self.stages):
            for j, (px, py) in enumerate(stage):
                bx = x0 + (k % 4) * (bw + gap)
                by = y0 + (k // 4) * (bh + gap)
                k += 1
                rect = pygame.Rect(bx, by, bw, bh)
                sel = ui["sel"] == (si, j)
                done = self.point_done[si][j]
                col = (90, 160, 90) if sel else ((50, 80, 56) if done else (60, 66, 74))
                pygame.draw.rect(self.screen, col, rect, border_radius=6)
                pygame.draw.rect(self.screen, (220, 230, 160) if sel else (150, 160, 170),
                                 rect, 2, border_radius=6)
                lab = self.font.render(self.point_labels[si][j], True, (240, 240, 240))
                self.screen.blit(lab, lab.get_rect(center=rect.center))
                ui["rects"].append((rect, (si, j)))
        ok = pygame.Rect(W // 2 - 170, H - 110, 160, 50)
        cancel = pygame.Rect(W // 2 + 10, H - 110, 160, 50)
        ui["ok_rect"], ui["cancel_rect"] = ok, cancel
        pygame.draw.rect(self.screen, (70, 130, 70) if ui["sel"] else (55, 60, 66),
                         ok, border_radius=6)
        pygame.draw.rect(self.screen, (130, 70, 60), cancel, border_radius=6)
        to = self.font.render("确认开火", True, (240, 240, 240))
        self.screen.blit(to, to.get_rect(center=ok.center))
        tc = self.font.render("取消 (ESC)", True, (240, 240, 240))
        self.screen.blit(tc, tc.get_rect(center=cancel.center))

    def spawn_defenders(self):
        """在当前阶段各区域点周围生成守军"""
        if self.sh_idx >= len(self.stages):
            return
        pts = self.stages[self.sh_idx]
        total = 4 + self.sh_idx * 2
        per = max(1, total // len(pts))
        for px, py in pts:
            for _ in range(per):
                if sum(1 for e in self.enemies if e.alive) >= MAX_ENEMIES:
                    return
                for _try in range(30):
                    x = px + random.uniform(-3.2, 3.2)
                    y = py + random.uniform(-2.2, 2.2)
                    if not is_solid(x, y):
                        self.enemies.append(Enemy(x, y, self.sh_idx + 1))
                        break

    def spawn_enemy_north(self):
        for _try in range(30):
            x = random.uniform(1.5, MW - 1.5)
            y = random.uniform(1.5, 4.5)
            if not is_solid(x, y):
                self.enemies.append(Enemy(x, y, self.sh_idx + 1))
                break

    def spawn_ally(self):
        for _try in range(30):
            x = self.player.x + random.uniform(-2, 2)
            y = self.player.y + random.uniform(-2, 2)
            if not is_solid(x, y):
                self.allies.append(Ally(x, y, len(self.allies)))
                return

    def update_battle(self, dt):
        """敌军增援与反扑"""
        if self.victory:
            return
        # 无尽模式: 敌军持续增援, 随时间变强; 战友定时归队
        if self.endless:
            self.endless_t += dt
            self.endless_spawn_t -= dt
            if self.endless_spawn_t <= 0:
                alive_now = sum(1 for e in self.enemies if e.alive)
                n = 2 + int(self.endless_t // 45)      # 每45秒多刷1人
                for _ in range(n):
                    if alive_now < MAX_ENEMIES:
                        self.spawn_enemy_north()
                        alive_now += 1
                self.endless_spawn_t = max(4.0, 10.0 - self.endless_t / 60.0)
            self.endless_ally_t -= dt
            if self.endless_ally_t <= 0:
                self.endless_ally_t = 45.0
                if sum(1 for a in self.allies if a.alive) < 3:
                    self.spawn_ally()
                    self.shout = ("战友归队!", 1.2)
            return
        alive = sum(1 for e in self.enemies if e.alive)
        # 撤离期结束 -> 敌军反扑
        if self.evac_t > 0:
            self.evac_t -= dt
            if self.evac_t <= 0:
                n = 0
                for _ in range(4):
                    if alive + n < MAX_ENEMIES:
                        self.spawn_enemy_north()
                        n += 1
                self.shout = ("敌军反扑了! 准备战斗!", 2.0)
        # 据点未占领: 定时增援守军
        self.reinforce_t -= dt
        if self.reinforce_t <= 0 and self.sh_idx < len(self.stages):
            self.reinforce_t = 15.0
            if alive < MAX_ENEMIES - 1:
                self.spawn_enemy_north()
                self.spawn_enemy_north()

    def update_capture(self, dt):
        """据点人数判定: 我方多则进度条向绿色推进; 阶段内所有点攻占后进入下一阶段"""
        if self.victory or self.sh_idx >= len(self.stages):
            return
        si = self.sh_idx
        stage = self.stages[si]
        self.zone_counts = []
        for j, (px, py) in enumerate(stage):
            if self.point_done[si][j]:
                self.zone_counts.append((0, 0))
                continue
            ours = 1 if math.hypot(self.player.x - px, self.player.y - py) < CAPTURE_R else 0
            ours += sum(1 for a in self.allies
                        if a.alive and math.hypot(a.x - px, a.y - py) < CAPTURE_R)
            theirs = sum(1 for e in self.enemies
                         if e.alive and math.hypot(e.x - px, e.y - py) < CAPTURE_R)
            self.zone_counts.append((ours, theirs))
            if ours > theirs:
                self.point_prog[si][j] += (6 + 2 * min(ours, 4)) * dt
                if self.point_prog[si][j] >= 100:
                    self.point_prog[si][j] = 0
                    self.point_done[si][j] = True
                    self.shout = (f"{self.point_labels[si][j]} 区攻占!", 1.5)
            elif ours < theirs:
                self.point_prog[si][j] = max(0.0, self.point_prog[si][j] - 6 * dt)
        # 本阶段全部攻占 -> 下一阶段
        if all(self.point_done[si]):
            self.sh_idx += 1
            self.evac_t = 30.0
            self.wave = self.sh_idx + 1
            # 攻占后补充战友 (最多5人)
            alive_allies = sum(1 for a in self.allies if a.alive)
            for _ in range(min(3 + self.sh_idx, 5) - alive_allies):
                self.spawn_ally()
            if self.sh_idx >= len(self.stages):
                if self.map_key == "C":
                    # 无尽模式: 不设胜利, 转入持续对抗
                    self.endless = True
                    self.endless_t = 0.0
                    self.endless_spawn_t = 5.0
                    self.endless_ally_t = 45.0
                    self.shout = ("据点全部光复! 无尽对抗开始, 活下去!", 3.0)
                else:
                    self.victory = True
                    self.shout = ("据点全部光复!", 3.0)
            else:
                self.spawn_defenders()
                self.shout = ("区域攻占! 30秒后敌军反扑, 迅速撤离!", 2.5)

    # ---------- 3D 渲染 ----------
    def render_world(self, cam_x, cam_y, angle, eye, pitch, fov):
        proj = (W / 2) / math.tan(fov / 2)
        horizon = HORIZON + pitch
        # 天空(铅灰冬日)与地面(雪原)
        self.screen.fill((158, 168, 178), (0, 0, W, int(horizon)))
        self.screen.fill((225, 230, 238), (0, int(horizon), W, H - int(horizon)))
        zbuf = []
        for c in range(NUM_RAYS):
            ray_a = angle - fov / 2 + fov * (c + 0.5) / NUM_RAYS
            sin_a, cos_a = math.sin(ray_a), math.cos(ray_a)
            mapx, mapy = int(cam_x), int(cam_y)
            ddx = abs(1 / cos_a) if abs(cos_a) > 1e-6 else 1e9
            ddy = abs(1 / sin_a) if abs(sin_a) > 1e-6 else 1e9
            if cos_a < 0:
                stepx, sdx = -1, (cam_x - mapx) * ddx
            else:
                stepx, sdx = 1, (mapx + 1 - cam_x) * ddx
            if sin_a < 0:
                stepy, sdy = -1, (cam_y - mapy) * ddy
            else:
                stepy, sdy = 1, (mapy + 1 - cam_y) * ddy
            side, tile = 0, 0
            for _ in range(64):
                if sdx < sdy:
                    sdx += ddx
                    mapx += stepx
                    side = 0
                else:
                    sdy += ddy
                    mapy += stepy
                    side = 1
                if 0 <= mapx < MW and 0 <= mapy < MH and MAP[mapy][mapx] != 0:
                    tile = MAP[mapy][mapx]
                    break
                if not (0 <= mapx < MW and 0 <= mapy < MH):
                    tile = 1
                    break
            raw = (sdx - ddx) if side == 0 else (sdy - ddy)
            dist = max(0.02, raw * math.cos(ray_a - angle))
            zbuf.append(dist)
            scale = proj / dist
            top = horizon - scale * eye
            bot = horizon + scale * (1 - eye)
            c1, c2 = WALL_COLORS.get(tile, WALL_COLORS[1])
            col = c2 if side else c1
            fog = max(0.3, 1 - dist / 15)
            col = tuple(int(v * fog) for v in col)
            pygame.draw.rect(self.screen, col, (c * COL_W, int(top), COL_W, int(bot - top)))
        return zbuf, proj, horizon

    def project(self, cam_x, cam_y, angle, proj, horizon, eye, wx, wy):
        dx, dy = wx - cam_x, wy - cam_y
        dist = math.hypot(dx, dy)
        ang = norm_ang(math.atan2(dy, dx) - angle)
        if abs(ang) > self.fov / 2 + 0.35 or dist < 0.05:
            return None
        sx = W / 2 + math.tan(ang) * proj
        scale = proj / dist
        base_y = horizon + scale * (1 - eye)
        return sx, base_y, scale, dist

    def draw_sprite(self, img, proj_res, zbuf, h_ratio, w_ratio=None, flash=False):
        sx, base_y, scale, dist = proj_res
        sh = scale * h_ratio
        sw = scale * (w_ratio if w_ratio else h_ratio * img.get_width() / img.get_height())
        if sh < 2:
            return
        key = (id(img), int(sw), int(sh), flash)
        surf = self._sprite_cache.get(key)
        if surf is None:
            surf = pygame.transform.smoothscale(img, (max(1, int(sw)), max(1, int(sh))))
            if flash:
                tint = surf.copy()
                tint.fill((255, 230, 120), special_flags=pygame.BLEND_ADD)
                surf = tint
            if len(self._sprite_cache) > 400:
                self._sprite_cache.clear()
            self._sprite_cache[key] = surf
        x0 = int(sx - sw / 2)
        if x0 >= W or x0 + sw <= 0:  # 精灵完全在屏幕外
            return
        col0 = max(0, min(NUM_RAYS - 1, x0 // COL_W))
        col1 = max(0, min(NUM_RAYS - 1, (x0 + int(sw)) // COL_W))
        mid = (col0 + col1) // 2
        if zbuf[mid] > dist - 0.35:
            self.screen.blit(surf, (x0, int(base_y - sh)))

    def draw_fire(self, pr, zbuf):
        """绘制3D篝火: 木柴 + 摇曳火焰"""
        sx, base_y, scale, dist = pr
        if scale < 6:
            return
        col = max(0, min(NUM_RAYS - 1, int(sx // COL_W)))
        if zbuf[col] <= dist - 0.35:
            return
        cx, by = int(sx), int(base_y)
        u = scale * 0.012
        # 火光地面光晕
        glow_r = int(u * 14)
        if glow_r > 2:
            glow = pygame.Surface((glow_r * 2, glow_r), pygame.SRCALPHA)
            pygame.draw.ellipse(glow, (255, 140, 40, 60), (0, 0, glow_r * 2, glow_r))
            self.screen.blit(glow, (cx - glow_r, by - glow_r // 2))
        # 木柴
        pygame.draw.rect(self.screen, (95, 62, 36),
                         (cx - int(u * 10), by - int(u * 4), int(u * 20), int(u * 4)))
        pygame.draw.rect(self.screen, (75, 50, 30),
                         (cx - int(u * 6), by - int(u * 8), int(u * 12), int(u * 4)))
        # 三层火焰 (大小/颜色/抖动不同)
        flame_cols = [(255, 110, 30), (255, 180, 60), (255, 235, 140)]
        for i in range(3):
            fh = u * (9 + 3.5 * math.sin(self.t * 9 + i * 2.1))
            r = max(1, int(u * (5 - i * 1.4)))
            fx = cx + int(math.sin(self.t * 7 + i * 1.7) * u * 2)
            fy = by - int(u * 6 + fh * (i * 0.45 + 0.3))
            pygame.draw.circle(self.screen, flame_cols[i], (fx, fy), r)

    # ---------- 武器视图 ----------
    def draw_weapon(self, dt_ms):
        p = self.player
        img = self.aa_img if p.mounted == 2 else (
            self.mg_img if p.mounted else (
                self.rocket_img if p.slot == 3 else self.weapon_imgs[p.slot]))
        iw, ih = img.get_size()
        scale = 0.85 if not p.mounted else 1.0
        # 姿态影响武器高度
        stance_dy = [0, 26, 60][p.stance]
        # 换弹: 下沉+翻转
        wpn = p.weapon
        reload_frac = 0.0
        if self.reloading > 0:
            reload_frac = 1 - self.reloading / wpn["reload"]
        dip = math.sin(min(1, reload_frac) * math.pi) * 130
        rot = -math.sin(min(1, reload_frac) * math.pi) * 30
        # 检视: 转到屏幕中央展示
        if self.inspecting > 0:
            t = 1 - self.inspecting / 2.4
            rot += math.sin(t * math.pi * 2) * 18
        # 切换: 收起
        if self.switching > 0:
            dip += (self.switching / 0.25) * 160
        surf = pygame.transform.rotozoom(img, rot, scale)
        sw, sh = surf.get_size()
        if self.ads and not p.mounted:
            pos = (W // 2 - sw // 2 + int(p.lean * -14), H - sh - 40 + int(self.recoil) + stance_dy // 2)
        elif p.mounted:
            pos = (W // 2 - sw // 2, H - sh + 30 + int(self.recoil))
        else:
            pos = (int(W * 0.58) - p.lean * 30, H - sh - 30 + int(dip) + int(self.recoil) + stance_dy)
        if self.inspecting > 0:
            pos = (W // 2 - sw // 2, H // 2 - sh // 2 + 60)
        self.screen.blit(surf, pos)

    # ---------- 准星 ----------
    def draw_crosshair(self):
        p = self.player
        if self.ads:
            pygame.draw.circle(self.screen, (240, 240, 240), (W // 2, H // 2 + int(self.recoil * 0.3 + self.player.pitch)), 2)
            return
        wpn = p.weapon
        gap = 8 + int(self.bloom * 8)
        if p.moving:
            gap += 5
        if p.stance == 2:
            gap = int(gap * 0.7)
        length = 8
        cx, cy = W // 2, H // 2 + int(self.player.pitch)
        c = (240, 240, 240)
        pygame.draw.line(self.screen, c, (cx - gap - length, cy), (cx - gap, cy), 2)
        pygame.draw.line(self.screen, c, (cx + gap, cy), (cx + gap + length, cy), 2)
        pygame.draw.line(self.screen, c, (cx, cy - gap - length), (cx, cy - gap), 2)
        pygame.draw.line(self.screen, c, (cx, cy + gap), (cx, cy + gap + length), 2)

    # ---------- 轮盘菜单 ----------
    async def radial_menu(self, title, options, open_key=None):
        """按住键呼出, 鼠标指向选择, 松开确认。返回选项索引或-1"""
        while True:
            await asyncio.sleep(0)
            mx, my = pygame.mouse.get_pos()
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    pygame.quit()
                    raise SystemExit
                if e.type == pygame.KEYUP and (e.key in (pygame.K_F2, pygame.K_5)
                                               or (open_key is not None and e.key == open_key)):
                    dx, dy = mx - W // 2, my - H // 2
                    if math.hypot(dx, dy) < 40:
                        return -1
                    ang = math.atan2(dy, dx) + math.pi / 2
                    if ang < 0:
                        ang += 2 * math.pi
                    return int(ang / (2 * math.pi) * len(options)) % len(options)
                if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                    return -1
            # 绘制
            overlay = pygame.Surface((W, H), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 150))
            self.screen.blit(overlay, (0, 0))
            n = len(options)
            dx, dy = mx - W // 2, my - H // 2
            sel = -1
            if math.hypot(dx, dy) >= 40:
                ang = math.atan2(dy, dx) + math.pi / 2
                if ang < 0:
                    ang += 2 * math.pi
                sel = int(ang / (2 * math.pi) * n) % n
            R1, R2 = 60, 150
            for i, opt in enumerate(options):
                a_mid = -math.pi / 2 + (i + 0.5) * 2 * math.pi / n
                a0 = -math.pi / 2 + i * 2 * math.pi / n + 0.06
                a1 = -math.pi / 2 + (i + 1) * 2 * math.pi / n - 0.06
                pts = [(W // 2 + math.cos(a) * r, H // 2 + math.sin(a) * r)
                       for a, r in [(a0, R1), (a1, R1), (a1, R2), (a0, R2)]]
                # 扇形近似: 多点插值
                pts = []
                for k in range(13):
                    a = a0 + (a1 - a0) * k / 12
                    pts.append((W // 2 + math.cos(a) * R2, H // 2 + math.sin(a) * R2))
                for k in range(13):
                    a = a1 + (a0 - a1) * k / 12
                    pts.append((W // 2 + math.cos(a) * R1, H // 2 + math.sin(a) * R1))
                color = (200, 60, 50) if i == sel else (70, 80, 95)
                pygame.draw.polygon(self.screen, color, pts)
                lx = W // 2 + math.cos(a_mid) * (R1 + R2) / 2
                ly = H // 2 + math.sin(a_mid) * (R1 + R2) / 2
                t = self.small.render(opt, True, (255, 255, 255))
                self.screen.blit(t, t.get_rect(center=(lx, ly)))
            t = self.font.render(title, True, (255, 255, 255))
            self.screen.blit(t, t.get_rect(center=(W // 2, H // 2)))
            pygame.display.flip()
            self.clock.tick(FPS)

    # ---------- HUD ----------
    def draw_hud(self):
        p = self.player
        # 血条
        pygame.draw.rect(self.screen, (40, 40, 40), (18, H - 46, 180, 16))
        hp_w = int(176 * p.hp / 100)
        hp_col = (80, 200, 90) if p.hp > 40 else (220, 80, 60)
        pygame.draw.rect(self.screen, hp_col, (20, H - 44, hp_w, 12))
        self.screen.blit(self.small.render(f"生命 {p.hp}", True, (255, 255, 255)), (18, H - 68))
        if getattr(self, "regen_active", False):
            self.screen.blit(self.small.render("呼吸回血中...", True, (120, 255, 120)), (90, H - 68))
        # 姿态
        stance_txt = ["站立", "蹲下", "卧倒"][p.stance]
        if p.mounted:
            stance_txt = "机枪位"
        lean_txt = "  ◀探头" if p.lean < 0 else ("  探头▶" if p.lean > 0 else "")
        self.screen.blit(self.small.render(stance_txt + lean_txt, True, (200, 210, 230)), (18, H - 90))
        # 弹药
        if p.in_tank:
            t = self.font.render(f"坦克装甲 {p.tank_ref['hp']}/100  F离开", True, (150, 255, 150))
            self.screen.blit(t, (W - t.get_width() - 18, H - 40))
        wpn = p.weapon
        if p.slot == 3:
            ammo = f"{wpn['name']}  {p.rocket_mag}/1 火箭弹×{p.rocket} [{p.rocket_mode}]"
        else:
            ammo = f"{wpn['name']}  {p.cur_mag} / {'∞' if p.mounted else p.reserve}"
        t = self.font.render(ammo, True, (255, 240, 200))
        self.screen.blit(t, (W - t.get_width() - 18, H - 66))
        # 手榴弹/燃烧瓶: 攒满1个才显示
        if p.nades >= 1:
            t = self.font.render(f"手榴弹 ×{p.nades}", True, (180, 255, 180))
            self.screen.blit(t, (W - t.get_width() - 18, H - 94))
        if p.molotov >= 1:
            t = self.font.render(f"燃烧瓶 ×{p.molotov}", True, (255, 180, 80))
            self.screen.blit(t, (W - t.get_width() - 18, H - 118))
        # 寒冷值条
        cold_frac = min(1.0, self.cold / 120)
        cw = int(176 * cold_frac)
        cold_col = (110, 170, 255) if self.cold <= 100 else (255, 90, 90)
        pygame.draw.rect(self.screen, (40, 40, 40), (18, H - 24, 180, 12))
        pygame.draw.rect(self.screen, cold_col, (20, H - 22, cw, 8))
        self.screen.blit(self.small.render(f"寒冷 {int(self.cold)}", True,
                                           (170, 210, 255) if self.cold <= 100 else (255, 120, 120)),
                         (204, H - 26))
        # 失温警告
        if self.cold > 100:
            if int(self.t * 2) % 2 == 0:  # 闪烁
                t = self.font.render("失温! 生命持续流失, 快去篝火旁取暖!", True, (255, 80, 80))
                self.screen.blit(t, t.get_rect(center=(W // 2, 60)))
        # 篝火取暖进度
        if self.fire_wait > 0:
            frac = self.fire_wait / 2.0
            bw = 160
            pygame.draw.rect(self.screen, (60, 55, 45), (W // 2 - bw // 2, H - 150, bw, 12))
            pygame.draw.rect(self.screen, (255, 170, 60),
                             (W // 2 - bw // 2 + 2, H - 148, int((bw - 4) * frac), 8))
            t = self.small.render("取暖中...", True, (255, 200, 120))
            self.screen.blit(t, t.get_rect(center=(W // 2, H - 165)))
        # 区域/击杀
        if self.endless:
            mm, ss = int(self.endless_t) // 60, int(self.endless_t) % 60
            hud = f"无尽模式  存活 {mm:02d}:{ss:02d}   击杀 {self.kills}   得分 {self.score}"
        else:
            stage_txt = "/".join(self.point_labels[self.sh_idx]) \
                if self.sh_idx < len(self.stages) else "完"
            hud = (f"区域 {stage_txt} ({min(self.sh_idx + 1, len(self.stages))}/{len(self.stages)})"
                   f"   击杀 {self.kills}   得分 {self.score}")
        self.screen.blit(self.small.render(hud, True, (220, 220, 220)),
                         (W // 2 - 110, 10))
        # 炮击就绪提示
        if self.score >= 20000 and int(self.t * 2) % 2 == 0:
            t = self.font.render("炮击就绪! 按 6 呼叫支援", True, (255, 230, 120))
            self.screen.blit(t, t.get_rect(center=(W // 2, 100)))
        # 当前阶段每个未攻占点的进度条
        if self.sh_idx < len(self.stages):
            n = len(self.stages[self.sh_idx])
            gap = 12
            bw = (220 - (n - 1) * gap) // n
            x0 = W // 2 - (n * bw + (n - 1) * gap) // 2
            for j in range(n):
                if self.point_done[self.sh_idx][j]:
                    continue
                ours, theirs = (self.zone_counts[j]
                                if j < len(self.zone_counts) else (0, 0))
                if ours > theirs:
                    col = (90, 200, 100)
                elif theirs > ours:
                    col = (220, 80, 60)
                else:
                    col = (160, 160, 160)
                frac = max(0.0, min(1.0, self.point_prog[self.sh_idx][j] / 100))
                bx = x0 + j * (bw + gap)
                pygame.draw.rect(self.screen, (40, 40, 40), (bx, 32, bw, 14))
                pygame.draw.rect(self.screen, col, (bx + 2, 34, int((bw - 4) * frac), 10))
                t = self.small.render(
                    f"{self.point_labels[self.sh_idx][j]} 我{ours}敌{theirs}",
                    True, (230, 230, 230))
                self.screen.blit(t, t.get_rect(center=(bx + bw // 2, 58)))
        # 撤离倒计时
        if self.evac_t > 0 and not self.victory:
            t = self.font.render(f"撤离! {int(self.evac_t)} 秒后敌军反扑",
                                 True, (255, 210, 120))
            self.screen.blit(t, t.get_rect(center=(W // 2, 80)))
        # 换弹/检视提示
        if self.reloading > 0:
            t = self.font.render("换弹中...", True, (255, 200, 120))
            self.screen.blit(t, t.get_rect(center=(W // 2, H // 2 + 60)))
        # 命中标记
        if self.hitmark > 0:
            c = (255, 60, 50) if self.hitmark_kill else (255, 255, 255)
            cx, cy = W // 2, H // 2 + int(self.player.pitch)
            for d in (-1, 1):
                pygame.draw.line(self.screen, c, (cx + 6 * d, cy + 6), (cx + 14 * d, cy + 14), 2)
                pygame.draw.line(self.screen, c, (cx + 6 * d, cy - 6), (cx + 14 * d, cy - 14), 2)
        # 受伤红晕
        if self.hurt_flash > 0:
            a = int(160 * min(1, self.hurt_flash * 2))
            vg = pygame.Surface((W, H), pygame.SRCALPHA)
            pygame.draw.rect(vg, (200, 0, 0, a), (0, 0, W, 26))
            pygame.draw.rect(vg, (200, 0, 0, a), (0, H - 26, W, 26))
            pygame.draw.rect(vg, (200, 0, 0, a), (0, 0, 26, H))
            pygame.draw.rect(vg, (200, 0, 0, a), (W - 26, 0, 26, H))
            self.screen.blit(vg, (0, 0))
        # 喊话
        if self.shout:
            txt, t_ = self.shout
            s = self.big.render(txt, True, (255, 230, 140))
            self.screen.blit(s, s.get_rect(center=(W // 2, 120)))
        # 炮位提示
        nd = math.hypot(p.x - self.nest[0], p.y - self.nest[1])
        na = math.hypot(p.x - self.aa_pos[0], p.y - self.aa_pos[1])
        if not p.mounted and nd < 1.6:
            t = self.font.render("按 F 操作九二式重机枪 (炮位内免伤)",
                                 True, (255, 255, 180))
            self.screen.blit(t, t.get_rect(center=(W // 2, H - 120)))
        elif not p.mounted and na < 1.6:
            t = self.font.render("按 F 操作防空炮, 可射击敌机 (炮位内免伤)",
                                 True, (255, 255, 180))
            self.screen.blit(t, t.get_rect(center=(W // 2, H - 120)))
        if p.mounted:
            t = self.small.render("炮位掩体保护中  按 F 离开", True, (150, 230, 150))
            self.screen.blit(t, t.get_rect(center=(W // 2, H - 100)))
        # 开场提示
        if self.hint_t > 0:
            lines = ["WASD/方向键移动 左键开火 右键机瞄 R换弹", "Z趴下 C蹲下 Q/E探头 G手雷 F交互",
                     "1/2/3或滚轮切枪 I检视 F2指令轮盘 5药品轮盘",
                     "严寒不断累积, 篝火旁2秒驱寒, 继续烤火回血",
                     "战壕内伤害减半; 据点内我方人多即可攻占, 占领后30秒撤离"]
            for i, ln in enumerate(lines):
                t = self.small.render(ln, True, (230, 230, 230))
                self.screen.blit(t, t.get_rect(center=(W // 2, H - 170 + i * 22)))

    def draw_minimap(self):
        ms = 6
        ox, oy = W - MW * ms - 12, 12
        bg = pygame.Surface((MW * ms, MH * ms), pygame.SRCALPHA)
        bg.fill((0, 0, 0, 110))
        self.screen.blit(bg, (ox, oy))
        for y in range(MH):
            for x in range(MW):
                if MAP[y][x]:
                    c = WALL_COLORS[MAP[y][x]][0]
                    pygame.draw.rect(self.screen, c, (ox + x * ms, oy + y * ms, ms - 1, ms - 1))
        for en in self.enemies:
            if en.alive:
                pygame.draw.circle(self.screen, (255, 70, 60),
                                   (ox + int(en.x * ms), oy + int(en.y * ms)), 2)
        p = self.player
        pygame.draw.circle(self.screen, (90, 200, 255), (ox + int(p.x * ms), oy + int(p.y * ms)), 3)
        pygame.draw.line(self.screen, (90, 200, 255),
                         (ox + int(p.x * ms), oy + int(p.y * ms)),
                         (ox + int((p.x + math.cos(p.angle)) * ms),
                          oy + int((p.y + math.sin(p.angle)) * ms)), 2)
        pygame.draw.circle(self.screen, (255, 220, 100),
                           (ox + int(self.nest[0] * ms), oy + int(self.nest[1] * ms)), 3)
        pygame.draw.circle(self.screen, (210, 180, 90),
                           (ox + int(self.aa_pos[0] * ms), oy + int(self.aa_pos[1] * ms)), 3)
        for fx, fy in self.campfires:  # 篝火: 橙色亮点
            pygame.draw.rect(self.screen, (255, 140, 40),
                             (ox + fx * ms - 2, oy + fy * ms - 2, 4, 4))
        for tx0, ty0, tw, th in self.trench_list:  # 战壕: 深褐区域
            pygame.draw.rect(self.screen, (110, 85, 60),
                             (ox + tx0 * ms, oy + ty0 * ms, tw * ms, th * ms))
        for si, stage in enumerate(self.stages):  # 据点: 绿圈/红圈
            for j, (sx_, sy_) in enumerate(stage):
                if si < self.sh_idx or (si == self.sh_idx and self.point_done[si][j]):
                    c = (80, 200, 90)
                elif si == self.sh_idx:
                    c = (255, 80, 70)
                else:
                    continue
                pygame.draw.circle(self.screen, c,
                                   (ox + int(sx_ * ms), oy + int(sy_ * ms)), 4, 2)
        for a in self.allies:  # 队友: 蓝点
            if a.alive:
                pygame.draw.circle(self.screen, (120, 180, 255),
                                   (ox + int(a.x * ms), oy + int(a.y * ms)), 2)

    def draw_trenches(self, zbuf, cam_x, cam_y, angle, proj, horizon, eye):
        """地面战壕: 投影四角填充深色区域"""
        items = []
        for x0, y0, w_, h_ in self.trench_list:
            corners = [(x0, y0), (x0 + w_, y0), (x0 + w_, y0 + h_), (x0, y0 + h_)]
            pts = [self.project(cam_x, cam_y, angle, proj, horizon, eye, cx, cy)
                   for cx, cy in corners]
            if any(p_ is None for p_ in pts):
                continue
            items.append((sum(p_[3] for p_ in pts) / 4, pts))
        for dist, pts in sorted(items, key=lambda t: -t[0]):
            col = max(0, min(NUM_RAYS - 1,
                             int(((pts[0][0] + pts[2][0]) / 2) / COL_W)))
            if zbuf[col] <= dist - 0.6:
                continue
            poly = [(int(p_[0]), int(p_[1])) for p_ in pts]
            pygame.draw.polygon(self.screen, (74, 62, 48), poly)
            pygame.draw.line(self.screen, (56, 46, 36), poly[0], poly[1], 2)
            pygame.draw.line(self.screen, (56, 46, 36), poly[3], poly[2], 2)

    def draw_zone_rings(self, cam_x, cam_y, angle, proj, horizon, eye):
        """据点占领圈: 地面圆环, 已攻占绿色, 进度弧随占领推进"""
        for si, stage in enumerate(self.stages):
            if si > self.sh_idx:
                continue
            for j, (px, py) in enumerate(stage):
                if si < self.sh_idx or self.point_done[si][j]:
                    arc_col, done, rest_col = (90, 200, 100), 16, (90, 200, 100)
                else:
                    ours, theirs = (self.zone_counts[j]
                                    if si == self.sh_idx and j < len(self.zone_counts)
                                    else (0, 0))
                    arc_col = (90, 200, 100) if ours >= theirs else (255, 90, 80)
                    done = int(16 * max(0.0, min(1.0, self.point_prog[si][j] / 100)))
                    rest_col = (200, 200, 200)
                pts = []
                for k in range(17):
                    a = k / 16 * 2 * math.pi
                    pr = self.project(cam_x, cam_y, angle, proj, horizon, eye,
                                      px + math.cos(a) * CAPTURE_R,
                                      py + math.sin(a) * CAPTURE_R)
                    pts.append(pr)
                if any(p_ is None for p_ in pts):
                    continue
                for k in range(16):
                    c = arc_col if k < done else rest_col
                    pygame.draw.line(self.screen, c,
                                     (int(pts[k][0]), int(pts[k][1])),
                                     (int(pts[k + 1][0]), int(pts[k + 1][1])), 2)

    # ---------- 大厅 ----------
    def draw_lobby(self):
        """游戏大厅: 选择地图"""
        self.screen.fill((28, 32, 40))
        t = self.big.render("东北抗联 · 林海雪原", True, (230, 230, 230))
        self.screen.blit(t, t.get_rect(center=(W // 2, 80)))
        sub = self.small.render("选择作战地图 (点击卡片或按 1 / 2 / 3)", True, (170, 180, 190))
        self.screen.blit(sub, sub.get_rect(center=(W // 2, 132)))
        self.lobby_cards = []
        for i, k in enumerate(MAPS):
            m = MAPS[k]
            cw, ch = 300, 250
            cx = W // 2 - 460 + i * 330
            cy = H // 2 - 20
            rect = pygame.Rect(cx, cy, cw, ch)
            self.lobby_cards.append((rect, k))
            pygame.draw.rect(self.screen, (55, 62, 74), rect, border_radius=8)
            pygame.draw.rect(self.screen, (120, 130, 145), rect, 2, border_radius=8)
            t1 = self.font.render(f"地图 {k}: {m['name']}", True, (255, 230, 180))
            self.screen.blit(t1, t1.get_rect(center=(rect.centerx, cy + 38)))
            # 区域简图: 每阶段一行圆点
            yy = cy + 84
            for stage in m["stages"]:
                n = len(stage)
                for q in range(n):
                    x = rect.centerx + (q - (n - 1) / 2) * 64
                    pygame.draw.circle(self.screen, (210, 95, 80), (int(x), yy), 9, 2)
                yy += 30
            t2 = self.small.render(m["desc"], True, (200, 205, 215))
            self.screen.blit(t2, t2.get_rect(center=(rect.centerx, cy + ch - 30)))
        t3 = self.small.render("按 B 查看键位指南   ESC 退出游戏", True, (140, 145, 155))
        self.screen.blit(t3, t3.get_rect(center=(W // 2, H - 26)))
        # 键位指南面板
        if self.show_keys:
            rows = [
                ("移动",        "WASD / 方向键"),
                ("跳跃",        "空格"),
                ("开火",        "鼠标左键"),
                ("开镜",        "鼠标右键"),
                ("换弹",        "R"),
                ("蹲下 / 趴下", "C / Z"),
                ("探头",        "Q / E"),
                ("切枪",        "1 2 3 / 滚轮 (4=火箭筒)"),
                ("高爆/穿甲",   "X (火箭筒)"),
                ("投掷轮盘",    "长按 G"),
                ("指令轮盘",    "F2"),
                ("药品轮盘",    "5"),
                ("炮击支援",    "6 (20000分)"),
                ("交互/进炮位", "F"),
                ("检视枪械",    "I"),
                ("视角",        "鼠标移动 (可抬头打飞机)"),
            ]
            pw, ph = 420, 44 + len(rows) * 26 + 14
            panel = pygame.Rect(W // 2 - pw // 2, 150, pw, ph)
            ov = pygame.Surface((W, H), pygame.SRCALPHA)
            ov.fill((0, 0, 0, 120))
            self.screen.blit(ov, (0, 0))
            pygame.draw.rect(self.screen, (45, 52, 64), panel, border_radius=10)
            pygame.draw.rect(self.screen, (150, 160, 175), panel, 2, border_radius=10)
            th = self.font.render("键 位 指 南", True, (255, 230, 180))
            self.screen.blit(th, th.get_rect(center=(panel.centerx, panel.y + 24)))
            yy = panel.y + 52
            for k, v in rows:
                self.screen.blit(self.small.render(k, True, (200, 210, 225)), (panel.x + 28, yy))
                self.screen.blit(self.small.render(v, True, (255, 190, 120)),
                                 (panel.x + 200, yy))
                yy += 26
            tb = self.small.render("按 B 关闭", True, (150, 158, 170))
            self.screen.blit(tb, tb.get_rect(center=(panel.centerx, panel.y + ph - 14)))

    # ---------- 主循环 ----------
    async def run(self):
        running = True
        while running:
            dt = min(0.05, self.clock.tick(FPS) / 1000)
            p = self.player

            # ===== 大厅场景 =====
            if self.scene == "lobby":
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        running = False
                    elif e.type == pygame.KEYDOWN:
                        if e.key == pygame.K_ESCAPE:
                            running = False
                        elif e.key == pygame.K_b:
                            self.show_keys = not self.show_keys
                        elif e.key == pygame.K_1 and not self.show_keys:
                            self.start_map("A")
                        elif e.key == pygame.K_2 and not self.show_keys:
                            self.start_map("B")
                        elif e.key == pygame.K_3 and not self.show_keys:
                            self.start_map("C")
                    elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                        for rect, k in self.lobby_cards:
                            if rect.collidepoint(e.pos):
                                self.start_map(k)
                                break
                if self.scene == "lobby":
                    self.draw_lobby()
                    pygame.display.flip()
                    self.clock.tick(FPS)
                await asyncio.sleep(0)
                continue

            # ===== 炮击支援选择界面 (游戏暂停) =====
            if self.strike_ui:
                for e in pygame.event.get():
                    if e.type == pygame.QUIT:
                        running = False
                    elif e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                        self.close_strike()
                    elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                        for rect, sij in self.strike_ui["rects"]:
                            if rect.collidepoint(e.pos):
                                self.strike_ui["sel"] = sij
                        if self.strike_ui["ok_rect"].collidepoint(e.pos) \
                                and self.strike_ui["sel"]:
                            self.call_strike()
                        elif self.strike_ui["cancel_rect"].collidepoint(e.pos):
                            self.close_strike()
                if self.strike_ui:
                    self.draw_strike_ui()
                    pygame.display.flip()
                    self.clock.tick(FPS)
                await asyncio.sleep(0)
                continue

            # ===== 事件 =====
            rel = [0, 0]
            _dbg_motion_count = 0
            for e in pygame.event.get():
                if e.type == pygame.QUIT:
                    running = False
                elif e.type == pygame.MOUSEMOTION:
                    _dbg_motion_count += 1
                    rel[0] += e.rel[0]
                    rel[1] += e.rel[1]
                elif e.type == pygame.KEYDOWN:
                    if e.key == pygame.K_ESCAPE:
                        running = False
                    if self.over or self.victory:
                        if e.key == pygame.K_r:
                            self.reset()
                        elif e.key == pygame.K_m:
                            self.scene = "lobby"
                            self.show_keys = False
                            pygame.mouse.set_visible(True)
                            pygame.event.set_grab(False)
                        continue
                    if e.key == pygame.K_r:
                        self.start_reload()
                    elif e.key == pygame.K_z:
                        p.stance = 0 if p.stance == 2 else 2
                    elif e.key == pygame.K_c:
                        p.stance = 0 if p.stance == 1 else 1
                    elif e.key == pygame.K_i:
                        if self.inspecting <= 0 and self.reloading <= 0:
                            self.inspecting = 2.4
                    elif e.key == pygame.K_4 and not p.mounted:
                        if self.switching <= 0:
                            self.switching = 0.25
                            self.pending_slot = 3
                            self.reloading = 0
                            self.inspecting = 0
                    elif e.key == pygame.K_g:
                        if not p.mounted and not p.in_tank:
                            opts = [f"手榴弹×{p.nades}", f"燃烧瓶×{p.molotov}", "取消"]
                            pygame.mouse.set_visible(True)
                            sel = await self.radial_menu("投掷物", opts, open_key=pygame.K_g)
                            pygame.mouse.set_visible(False)
                            pygame.mouse.set_pos(W // 2, H // 2)
                            if sel == 0 and p.nades >= 1:
                                p.nades -= 1
                                self.grenade_cd = 0.8
                                self.grenades.append(Grenade(p.x, p.y, p.angle, "grenade"))
                            elif sel == 1 and p.molotov >= 1:
                                p.molotov -= 1
                                self.grenade_cd = 0.8
                                self.grenades.append(Grenade(p.x, p.y, p.angle, "molotov"))
                    elif e.key == pygame.K_SPACE:
                        if not p.mounted and not p.in_tank and p.jump_z <= 0:
                            p.jump_vz = 4.5
                    elif e.key == pygame.K_x and p.slot == 3:
                        p.rocket_mode = "AP" if p.rocket_mode == "HE" else "HE"
                        self.shout = (f"切换至 {'穿甲弹' if p.rocket_mode == 'AP' else '高爆弹'}", 1.2)
                    elif e.key == pygame.K_f:
                        nd = math.hypot(p.x - self.nest[0], p.y - self.nest[1])
                        na = math.hypot(p.x - self.aa_pos[0], p.y - self.aa_pos[1])
                        # 坦克交互: 在坦克顶上 → 开盖/扔燃烧瓶/进入; 在坦克内 → 离开
                        if p.in_tank:
                            tk = p.tank_ref
                            p.in_tank = False
                            p.x, p.y = tk["x"], tk["y"] + 1.2
                            p.jump_z, p.jump_vz = 0.62, 0
                            p.tank_ref = None
                            self.shout = ("离开坦克", 1.0)
                        elif p.jump_z >= 0.5:
                            tk = self.tank_on(p.x, p.y)
                            if tk:
                                if not tk["hatch_open"]:
                                    tk["hatch_open"] = True
                                    self.shout = ("打开座舱盖! 再按F扔燃烧瓶", 1.6)
                                elif tk["burning"] > 0 or tk.get("interior_burn"):
                                    if tk["burning"] <= 0 and tk.get("interior_burn"):
                                        # 烧完, 可进入
                                        p.in_tank = True
                                        p.tank_ref = tk
                                        p.stance = 0
                                        self.shout = ("进入坦克! WASD驾驶, F离开", 2.0)
                                    else:
                                        self.shout = ("舱内还在燃烧, 等火烧完...", 1.2)
                                elif p.molotov >= 1:
                                    p.molotov -= 1
                                    tk["burning"] = 4.0
                                    tk["interior_burn"] = True
                                    self.shout = ("燃烧瓶扔进舱内! 等它烧完", 1.8)
                                else:
                                    self.shout = ("没有燃烧瓶! (击杀敌人攒0.15/个)", 1.5)
                            else:
                                self.shout = ("跳到坦克顶上才能操作", 1.0)
                        elif p.mounted:
                            pos = self.nest if p.mounted == 1 else self.aa_pos
                            p.mounted = None
                            p.x, p.y = pos[0], pos[1] + 0.9
                        elif nd < 1.6:
                            p.mounted = 1
                            p.stance = 0
                            p.x, p.y = self.nest
                        elif na < 1.6:
                            p.mounted = 2
                            p.stance = 0
                            p.x, p.y = self.aa_pos
                    elif e.key == pygame.K_6:
                        if self.score >= 20000 and not self.strike_ui:
                            self.open_strike()
                    elif e.key in (pygame.K_1, pygame.K_2, pygame.K_3) and not p.mounted:
                        idx = e.key - pygame.K_1
                        if idx != p.slot and self.switching <= 0:
                            self.switching = 0.25
                            self.pending_slot = idx
                            self.reloading = 0
                            self.inspecting = 0
                    elif e.key == pygame.K_F2:
                        opts = ["冲啊!", "坚持住!", "隐蔽!", "跟我来!", "节约弹药!", "胜利属于我们!"]
                        pygame.mouse.set_visible(True)
                        sel = await self.radial_menu("指令/口号", opts)
                        pygame.mouse.set_visible(False)
                        pygame.mouse.set_pos(W // 2, H // 2)
                        if sel >= 0:
                            self.shout = (opts[sel], 1.8)
                    elif e.key == pygame.K_5:
                        opts = [f"绷带×{p.meds['绷带']}", f"急救包×{p.meds['急救包']}",
                                f"炒面×{p.meds['炒面']}", "取消"]
                        pygame.mouse.set_visible(True)
                        sel = await self.radial_menu("使用药品", opts)
                        pygame.mouse.set_visible(False)
                        pygame.mouse.set_pos(W // 2, H // 2)
                        if sel == 0 and p.meds["绷带"] > 0 and p.hp < 100:
                            p.meds["绷带"] -= 1
                            p.hp = min(100, p.hp + 30)
                            self.shout = ("包扎完成 +30", 1.2)
                        elif sel == 1 and p.meds["急救包"] > 0 and p.hp < 100:
                            p.meds["急救包"] -= 1
                            p.hp = min(100, p.hp + 80)
                            self.shout = ("急救完成 +80", 1.2)
                        elif sel == 2 and p.meds["炒面"] > 0 and p.hp < 100:
                            p.meds["炒面"] -= 1
                            p.hp = min(100, p.hp + 10)
                            self.shout = ("吃了口炒面 +10", 1.2)
                elif e.type == pygame.MOUSEWHEEL and not p.mounted and not self.over:
                    if self.switching <= 0:
                        self.switching = 0.25
                        self.pending_slot = (p.slot - e.y) % 3
                        self.reloading = 0
                        self.inspecting = 0
                elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 3:
                    self.ads = True
                elif e.type == pygame.MOUSEBUTTONUP and e.button == 3:
                    self.ads = False

            if self.over or self.victory:
                # ===== 结算画面 =====
                self.screen.fill((16, 20, 16) if self.victory else (20, 16, 16))
                if self.victory:
                    t1 = self.big.render("据点全部光复!", True, (120, 220, 120))
                    t2 = self.font.render(
                        f"击杀 {self.kills}   存活战友 {sum(1 for a in self.allies if a.alive)}",
                        True, (255, 255, 255))
                else:
                    t1 = self.big.render(self.death_reason, True, (220, 70, 60))
                    if self.endless:
                        mm, ss = int(self.endless_t) // 60, int(self.endless_t) % 60
                        t2 = self.font.render(
                            f"无尽模式存活 {mm:02d}:{ss:02d}   击杀 {self.kills}   得分 {self.score}",
                            True, (255, 255, 255))
                    else:
                        t2 = self.font.render(
                            f"击杀 {self.kills}   推进至区域 {min(self.sh_idx + 1, len(self.stages))}/{len(self.stages)}",
                            True, (255, 255, 255))
                t3 = self.font.render("按 R 再战此图, M 返回大厅, ESC 退出", True, (200, 200, 200))
                self.screen.blit(t1, t1.get_rect(center=(W // 2, H // 2 - 70)))
                self.screen.blit(t2, t2.get_rect(center=(W // 2, H // 2)))
                self.screen.blit(t3, t3.get_rect(center=(W // 2, H // 2 + 50)))
                pygame.display.flip()
                await asyncio.sleep(0)
                continue

            # ===== 输入(持续) =====
            keys = pygame.key.get_pressed()
            mouse = pygame.mouse.get_pressed()
            sens = 0.0022 * (0.6 if self.ads else 1.0)
            p.angle += rel[0] * sens
            p.pitch = max(-380, min(120, p.pitch + rel[1] * 0.025))
            p.lean = (1 if keys[pygame.K_e] else 0) - (1 if keys[pygame.K_q] else 0)

            # 移动
            spd = p.speed() * (0.6 if self.ads else 1.0) * dt
            fwd = ((1 if keys[pygame.K_w] or keys[pygame.K_UP] else 0)
                   - (1 if keys[pygame.K_s] or keys[pygame.K_DOWN] else 0))
            side = ((1 if keys[pygame.K_d] or keys[pygame.K_RIGHT] else 0)
                    - (1 if keys[pygame.K_a] or keys[pygame.K_LEFT] else 0))
            p.moving = bool(fwd or side)
            if p.moving and p.in_tank:
                # 驾驶坦克: 慢速移动坦克本体, 玩家跟随
                tk = p.tank_ref
                ca, sa = math.cos(p.angle), math.sin(p.angle)
                tnx = tk["x"] + (ca * fwd - sa * side) * 1.8 * dt
                tny = tk["y"] + (sa * fwd + ca * side) * 1.8 * dt
                if not is_solid(tnx, tny):
                    tk["x"], tk["y"] = tnx, tny
                    tk["angle"] = p.angle
                p.x, p.y = tk["x"], tk["y"]
            elif p.moving and not p.mounted:
                ca, sa = math.cos(p.angle), math.sin(p.angle)
                nx = p.x + (ca * fwd - sa * side) * spd
                ny = p.y + (sa * fwd + ca * side) * spd
                r = 0.22
                if not is_solid(nx + (r if nx > p.x else -r), p.y):
                    p.x = nx
                if not is_solid(p.x, ny + (r if ny > p.y else -r)):
                    p.y = ny
            # 姿态过渡
            target_eye = [EYE_STAND, EYE_CROUCH, EYE_PRONE][p.stance]
            p.eye += (target_eye - p.eye) * min(1, dt * 8)
            # 开镜FOV过渡
            target_fov = FOV_ADS if self.ads else FOV
            self.fov += (target_fov - self.fov) * min(1, dt * 10)

            # 开火
            self.fire_cd -= dt
            if mouse[0] and self.fire_cd <= 0 and self.reloading <= 0 \
                    and self.switching <= 0 and self.inspecting <= 0 \
                    and not p.in_tank:
                self.shoot()
                if not p.weapon["auto"]:
                    pass  # 半自动由fire_cd控制节奏, 按住也可连续 but 慢
            # 换弹完成
            if self.reloading > 0:
                self.reloading -= dt
                if self.reloading <= 0:
                    if p.mounted == 1:
                        p.mg_mag = MG_NEST["mag"]
                    elif p.mounted == 2:
                        p.aa_mag = AA_NEST["mag"]
                    elif p.slot == 3:
                        p.rocket_mag = 1
                        p.rocket -= 1
                    else:
                        wpn = WEAPONS[p.slot]
                        need = wpn["mag"] - p.mags[p.slot]
                        take = min(need, p.reserve)
                        p.mags[p.slot] += take
                        p.reserve -= take
            # 切枪完成
            if self.switching > 0:
                self.switching -= dt
                if self.switching <= 0 and self.pending_slot >= 0:
                    p.slot = self.pending_slot
                    self.pending_slot = -1
            # 检视
            if self.inspecting > 0:
                self.inspecting -= dt
            # 其他计时
            self.bloom = max(0.0, self.bloom - dt * 3)
            self.recoil = max(0.0, self.recoil - dt * 60)
            self.shake = max(0.0, self.shake - dt * 30)
            self.hurt_flash = max(0.0, self.hurt_flash - dt)
            self.hitmark = max(0.0, self.hitmark - dt)
            self.grenade_cd = max(0.0, self.grenade_cd - dt)
            self.hint_t -= dt
            if self.shout:
                self.shout = (self.shout[0], self.shout[1] - dt)
                if self.shout[1] <= 0:
                    self.shout = None

            # ===== 更新 =====
            self.update_battle(dt)
            self.update_capture(dt)
            for en in self.enemies:
                if en.alive:
                    en.update(dt, self)
            self.enemies = [e for e in self.enemies if e.alive]
            for a in self.allies:
                if a.alive:
                    a.update(dt, self)
            self.allies = [a for a in self.allies if a.alive]
            # 敌军飞机 (只骚扰不伤人, 可用防空炮击落)
            self.plane_t -= dt
            if self.plane_t <= 0:
                self.plane_t = random.uniform(18.0, 35.0)
                direction = random.choice([-1, 1])
                self.planes.append({
                    "sx": -60.0 if direction > 0 else W + 60.0,
                    "sy": float(random.randint(HORIZON - 260, HORIZON - 80)),
                    "dir": direction, "spd": random.uniform(130, 210),
                    "hp": 120, "falling": False, "vy": 0.0,
                    "bob": random.uniform(0, 6)})
            for pl in self.planes:
                pl["bob"] += dt
                if pl["falling"]:
                    pl["vy"] += 420 * dt
                    pl["sy"] += pl["vy"] * dt
                    pl["sx"] += pl["dir"] * 40 * dt
                else:
                    pl["sx"] += pl["dir"] * pl["spd"] * dt
                    pl["sy"] += math.sin(pl["bob"] * 1.7) * 12 * dt
            self.planes = [pl for pl in self.planes
                           if -80 < pl["sx"] < W + 80 and pl["sy"] < H + 60]
            # 炮击支援炮弹
            for sh in self.strike_shells:
                sh[0] -= dt
                if sh[0] <= 0:
                    play(self.sounds, "boom")
                    self.shake = max(self.shake, 10)
                    self.strike_fx.append([sh[1], sh[2], 1.3])
                    for en in self.enemies:
                        if not en.alive:
                            continue
                        d = math.hypot(en.x - sh[1], en.y - sh[2])
                        if d < 2.4:
                            en.hp -= int(180 * (1 - d / 3))
                            if en.hp <= 0:
                                self.kill_enemy(en)
            self.strike_shells = [s for s in self.strike_shells if s[0] > 0]
            for fx in self.strike_fx:
                fx[2] -= dt
            self.strike_fx = [f for f in self.strike_fx if f[2] > 0]
            for g in self.grenades[:]:
                if g.update(dt):
                    self.grenades.remove(g)
                    self.explode(g.x, g.y, g.ntype)
            # 跳跃物理 (可落在坦克顶上, 高度0.62)
            if p.jump_z > 0 or p.jump_vz > 0:
                p.jump_vz -= 9.8 * dt
                p.jump_z += p.jump_vz * dt
                roof_tk = self.tank_on(p.x, p.y)
                if roof_tk and p.jump_vz <= 0 and p.jump_z <= 0.62:
                    p.jump_z = 0.62   # 站上坦克顶
                    p.jump_vz = 0
                elif p.jump_z <= 0:
                    p.jump_z = 0
                    p.jump_vz = 0
            # 坦克更新
            for tk in self.tanks:
                if not tk["alive"]:
                    if p.in_tank and p.tank_ref is tk:
                        p.in_tank = False
                        p.tank_ref = None
                        p.x, p.y = tk["x"] + 1.0, tk["y"] + 1.0
                        p.jump_z, p.jump_vz = 0, 0
                        self.shout = ("坦克被摧毁, 你被弹出!", 1.5)
                    continue
                if tk["burning"] > 0:
                    tk["burning"] -= dt
                    if tk["burning"] <= 0:
                        tk["burning"] = 0
                tk["fire_t"] = max(0, tk["fire_t"] - dt)
                # 坦克向玩家射击 (低强度: 间隔长, 伤害低, 距离近才打; 玩家在舱内不打)
                if tk["fire_t"] <= 0 and not self.over and not (p.in_tank and p.tank_ref is tk):
                    d = math.hypot(p.x - tk["x"], p.y - tk["y"])
                    if d < 8 and los_clear(tk["x"], tk["y"], p.x, p.y):
                        tk["fire_t"] = 6.0
                        play(self.sounds, "lmg")
                        self.shake = max(self.shake, 6)
                        self.hurt_player(random.randint(6, 12))
                        self.shout = ("坦克开火! 快躲进战壕!", 1.2)
                    else:
                        tk["fire_t"] = 1.5
            for f in self.floats[:]:
                f[3] -= dt
                if f[3] <= 0:
                    self.floats.remove(f)
            # 呼吸回血: 脱离伤害10秒后快速回血 (25点/秒)
            self.regen_active = (not self.over and p.hp < 100
                                 and p.hp > 0 and self.t - self.last_hurt_t >= 10.0)
            if self.regen_active:
                p.hp = min(100, p.hp + 25.0 * dt)
            self.update_weather(dt)

            # ===== 渲染 =====
            # 炮位 360° 自由旋转 (不再限制角度)
            cam_x = p.x - math.sin(p.angle) * p.lean * 0.3
            cam_y = p.y + math.cos(p.angle) * p.lean * 0.3
            shake_x = random.uniform(-self.shake, self.shake)
            shake_y = random.uniform(-self.shake, self.shake)
            zbuf, proj, horizon = self.render_world(
                cam_x, cam_y, p.angle, p.eye, p.pitch + shake_y, self.fov)
            self.draw_trenches(zbuf, cam_x, cam_y, p.angle, proj, horizon, p.eye)
            self.draw_zone_rings(cam_x, cam_y, p.angle, proj, horizon, p.eye)
            # 天空中的敌军飞机
            for pl in self.planes:
                px_ = int(pl["sx"])
                py_ = int(pl["sy"] + math.sin(pl["bob"] * 1.7) * 3 + (horizon - HORIZON))
                c = (60, 64, 70) if not pl["falling"] else (95, 75, 58)
                pygame.draw.ellipse(self.screen, c, (px_ - 22, py_ - 5, 44, 10))   # 机身
                pygame.draw.line(self.screen, c, (px_ - 2, py_), (px_ + 10, py_ - 14), 3)
                pygame.draw.rect(self.screen, c, (px_ - 16, py_ - 4, 32, 3))       # 下翼
                pygame.draw.rect(self.screen, c, (px_ - 10, py_ - 16, 24, 3))      # 上翼
                pygame.draw.rect(self.screen, c, (px_ - 26, py_ - 8, 6, 12))       # 尾翼
                if pl["falling"]:  # 坠落冒烟
                    for k in range(3):
                        pygame.draw.circle(self.screen, (120, 110, 100),
                                           (px_ - int(k * 14), py_ - 12 - k * 8), 6 - k)
            # 精灵: 敌人/队友/手雷/篝火/机枪位/据点旗帜
            draw_list = []
            for en in self.enemies:
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye, en.x, en.y)
                if pr:
                    draw_list.append((pr[3], ("enemy", en, pr)))
            for a in self.allies:
                if a.alive:
                    pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye, a.x, a.y)
                    if pr:
                        draw_list.append((pr[3], ("ally", a, pr)))
            for si, stage in enumerate(self.stages):
                if si > self.sh_idx:
                    break
                for j, (sx_, sy_) in enumerate(stage):
                    pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye, sx_, sy_)
                    if pr:
                        if si < self.sh_idx or self.point_done[si][j]:
                            state = 0   # 已攻占
                        elif si == self.sh_idx:
                            state = 1   # 当前目标
                        else:
                            state = 2   # 未激活
                        draw_list.append((pr[3], ("flag", (state), pr)))
            for g in self.grenades:
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye, g.x, g.y)
                if pr:
                    draw_list.append((pr[3], ("nade", g, pr)))
            for fx, fy in self.campfires:
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye, fx, fy)
                if pr:
                    draw_list.append((pr[3], ("fire", None, pr)))
            # 坦克
            for tk in self.tanks:
                if not tk["alive"]:
                    continue
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye,
                                  tk["x"], tk["y"])
                if pr:
                    draw_list.append((pr[3], ("tank", tk, pr)))
            if not p.mounted:
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye,
                                  self.nest[0], self.nest[1])
                if pr:
                    draw_list.append((pr[3], ("nest", None, pr)))
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye,
                                  self.aa_pos[0], self.aa_pos[1])
                if pr:
                    draw_list.append((pr[3], ("aa", None, pr)))
            for fx in self.strike_fx:
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye, fx[0], fx[1])
                if pr:
                    draw_list.append((pr[3], ("boomfx", fx, pr)))
            for _, (kind, obj, pr) in sorted(draw_list, key=lambda t: -t[0]):
                if kind == "enemy":
                    self.draw_sprite(self.enemy_img, pr, zbuf, 0.95,
                                     flash=(obj.flash_t > 0))
                    if obj.flash_t > 0:  # 枪口火光 + 曳光弹(明确反馈"他在打你")
                        sx, by, sc, _ = pr
                        gy = int(by - sc * 0.51)
                        r = max(3, int(sc * 0.07))
                        pygame.draw.circle(self.screen, (255, 230, 130), (int(sx), gy), r)
                        for a in range(6):  # 星形火光
                            ang = a * math.pi / 3 + self.t * 20
                            pygame.draw.line(self.screen, (255, 200, 80), (int(sx), gy),
                                             (int(sx + math.cos(ang) * r * 1.9),
                                              int(gy + math.sin(ang) * r * 1.9)), 2)
                        tx = W // 2 + random.randint(-70, 70)   # 曳光弹飞向玩家
                        ty = HORIZON + random.randint(-40, 40)
                        pygame.draw.line(self.screen, (255, 240, 170),
                                         (int(sx), gy), (tx, ty), 2)
                elif kind == "ally":
                    self.draw_sprite(self.ally_img, pr, zbuf, 0.95,
                                     flash=(obj.flash_t > 0))
                    if obj.flash_t > 0:  # 队友枪口火光
                        sx, by, sc, _ = pr
                        pygame.draw.circle(self.screen, (255, 230, 130),
                                           (int(sx), int(by - sc * 0.51)),
                                           max(2, int(sc * 0.05)))
                elif kind == "flag":
                    state = obj
                    sx, by, sc, dst = pr
                    col_i = max(0, min(NUM_RAYS - 1, int(sx // COL_W)))
                    if zbuf[col_i] > dst - 0.5:
                        top = by - sc * 1.5
                        if state == 0:
                            fcol = (80, 200, 90)     # 已攻占: 红旗变绿
                        elif state == 1:
                            fcol = (210, 60, 50)     # 当前目标: 敌旗
                        else:
                            fcol = (150, 150, 150)   # 未激活
                        pygame.draw.line(self.screen, (120, 100, 80),
                                         (int(sx), int(by)), (int(sx), int(top)),
                                         max(1, int(sc * 0.02)))
                        pygame.draw.polygon(self.screen, fcol, [
                            (int(sx), int(top)),
                            (int(sx + sc * 0.45), int(top + sc * 0.12)),
                            (int(sx), int(top + sc * 0.24))])
                elif kind == "nade":
                    sx, by, sc, _ = pr
                    r = max(2, int(sc * 0.05))
                    pygame.draw.circle(self.screen, (40, 45, 40),
                                       (int(sx), int(by - sc * obj.z - r)), r)
                elif kind == "tank":
                    sx, by, sc, dst = pr
                    col_i = max(0, min(NUM_RAYS - 1, int(sx // COL_W)))
                    if zbuf[col_i] > dst - 0.5:
                        self.draw_sprite(self.tank_img, pr, zbuf, 0.75)
                        if obj["burning"] > 0:
                            pygame.draw.circle(self.screen, (255, 120, 40),
                                               (int(sx), int(by - sc * 0.7)),
                                               max(3, int(sc * 0.15)))
                        if obj["hatch_open"]:
                            pygame.draw.circle(self.screen, (200, 60, 50),
                                               (int(sx), int(by - sc * 0.55)),
                                               max(2, int(sc * 0.06)))
                elif kind == "fire":
                    self.draw_fire(pr, zbuf)
                elif kind == "aa":
                    self.draw_sprite(self.aa_img, pr, zbuf, 0.55)
                elif kind == "boomfx":
                    sx, by, sc, _ = pr
                    age = 1.3 - obj[2]                      # 0->1.3 爆炸进程
                    r = int(sc * (0.35 + age * 0.45))
                    col = ((255, 180, 60) if age < 0.45
                           else (200, 90, 40) if age < 0.9 else (110, 100, 95))
                    pygame.draw.circle(self.screen, col,
                                       (int(sx), int(by - sc * 0.55)), r)
                    pygame.draw.circle(self.screen, (255, 230, 140),
                                       (int(sx), int(by - sc * 0.55)), max(1, r // 2))
                else:
                    sx, by, sc, _ = pr
                    w2 = sc * 0.8
                    h2 = sc * 0.35
                    pygame.draw.rect(self.screen, (150, 130, 95),
                                     (int(sx - w2 / 2), int(by - h2), int(w2), int(h2)))
            # 飘字
            for txt, fx, fy, ft in self.floats:
                pr = self.project(cam_x, cam_y, p.angle, proj, horizon, p.eye, fx, fy)
                if pr:
                    s = self.small.render(txt, True, (255, 230, 130))
                    self.screen.blit(s, (int(pr[0] - s.get_width() / 2),
                                         int(pr[1] - pr[2] - (1.2 - ft) * 40)))
            # 屏幕震动应用到手绘层
            if shake_x or shake_y:
                pass  # 世界层已用shake_y, 保持简单
            self.draw_weapon(dt)
            self.draw_snow()
            self.draw_crosshair()
            self.draw_hud()
            self.draw_minimap()
            # 检视信息
            if self.inspecting > 0:
                wpn = p.weapon
                t1 = self.font.render(wpn["name"], True, (255, 240, 200))
                t2 = self.small.render(wpn["info"], True, (220, 220, 220))
                self.screen.blit(t1, t1.get_rect(center=(W // 2, H // 2 - 70)))
                self.screen.blit(t2, t2.get_rect(center=(W // 2, H // 2 - 40)))
            pygame.display.flip()
            # 浏览器协作式让帧 (pygbag 必需)
            await asyncio.sleep(0)

        pygame.quit()


if __name__ == "__main__":
    asyncio.run(Game().run())
