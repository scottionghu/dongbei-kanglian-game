# -*- coding: utf-8 -*-
"""rebuild 后对 build/web/index.html 打补丁:
1) 标题改为中文游戏名
2) 插入竖屏提示遮罩 + 横屏锁定脚本 (body 开头)
用法: python patch_index.py  (在 webgame 目录下执行)
"""
import io
import os

P = os.path.join(os.path.dirname(__file__), "build", "web", "index.html")
TITLE = "<title>东北抗联小游戏，点击即玩！！！！！</title>"
OVERLAY = '''<body>

    <!-- 竖屏提示: 手机竖屏时要求横屏游玩 -->
    <div id="rotate-overlay" style="display:none;position:fixed;inset:0;background:#101418;color:#fff;z-index:9999999;text-align:center;font-family:sans-serif;">
        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);">
            <div style="font-size:72px;line-height:1;">&#x1F504;</div>
            <div style="font-size:22px;margin-top:16px;">请将手机横过来游玩</div>
            <div style="font-size:14px;margin-top:8px;color:#9aa;">横屏后点击屏幕即可开始</div>
        </div>
    </div>
    <script type="application/javascript">
    (function () {
        var ov = document.getElementById('rotate-overlay');
        var coarse = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
        function chkOri() {
            if (!coarse) { ov.style.display = 'none'; return; }
            ov.style.display = (window.innerHeight > window.innerWidth) ? 'block' : 'none';
        }
        window.addEventListener('resize', chkOri);
        window.addEventListener('orientationchange', chkOri);
        setInterval(chkOri, 800);
        chkOri();
        // 首次触摸: 请求全屏并锁定横屏 (安卓生效, iOS自动忽略, 靠提示遮罩兜底)
        if (coarse) {
            window.addEventListener('touchend', function tryLock() {
                var el = document.documentElement;
                var p = el.requestFullscreen ? el.requestFullscreen() : Promise.reject();
                Promise.resolve(p).then(function () {
                    if (screen.orientation && screen.orientation.lock)
                        return screen.orientation.lock('landscape');
                }).catch(function () {});
                window.removeEventListener('touchend', tryLock);
            });
        }
    })();
    </script>
'''

with io.open(P, "r", encoding="utf-8") as f:
    html = f.read()

if "<title>webgame</title>" in html:
    html = html.replace("<title>webgame</title>", TITLE)
elif TITLE not in html:
    print("WARN: title tag not found")

if "rotate-overlay" not in html:
    html = html.replace("<body>", OVERLAY, 1)
else:
    print("rotate-overlay already present")

with io.open(P, "w", encoding="utf-8", newline="") as f:
    f.write(html)

print("patched:", P)
